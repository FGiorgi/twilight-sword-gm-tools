# Twilight Sword GM Tools

Two GM windows for the Twilight Sword (Custom System Builder) setup. Requires **Twilight Sword Automation** 0.29.0+.
Open them from the buttons at the top of the **Actors** sidebar, from *Game Settings → Twilight Sword GM Tools*, or with
`game.modules.get("twilight-sword-gm-tools").api.openEncounterBuilder()` / `.openMonsterCreator()`.

## Encounter builder
- Party: loaded from the Party sheet (or every Champion with a player); Advancements read from the automation module. NPC allies count as PCs.
- Rating (Core Rulebook p. 164): collective Threat vs number of Champions. N to 1.5N is the rulebook's range; above 1.5N is "extremely challenging".
  Bands: Trivial < 0.5N, Easy < N, Balanced ≤ 1.25N, Hard ≤ 1.5N, Deadly above (the 1.25N split is an interpretation).
- Threat X counts as the number of PCs; Black variants add +1 Threat. Warnings when Blue (HOPE 8) or Red/Black (HOPE 16) variants appear early.
- House rule (setting, off by default): each Advancement adds a fraction of a Champion to party power (default 0.1).
- Variants and elements per entry; **Place on scene** creates the variant actors (folder *Encounter Monsters*), places the tokens and can add them to the combat.
- Encounters can be saved and loaded.

## Monster creator
- Stats with guidance ranges for the chosen Threat, computed from your Monster compendium (the rulebook has no rules for building Monsters from scratch).
- Variants (p. 182): Blue, Red, Black and Elemental, applied to stats and to the damage written in the texts.
- Actions, special actions and feats: copy them from any Monster (both languages, animation included) or build new ones with the **action builder**,
  which writes the card text in the wording the automation module reads (statuses and durations, ability rolls, ignoring Armor, self effects, Monster spells).
- Every row shows what the automation will do with it.
- Saves an English and an Italian actor (folders *Homebrew Monsters* / *Mostri homebrew (IT)*) sharing the same key.
