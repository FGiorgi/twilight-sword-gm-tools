/* Twilight Sword GM Tools — encounter builder and Monster creator for the Twilight Sword (CSB) system. */
import { t } from "./i18n.js";
import * as rules from "./rules.js";
import { MODULE_ID, TSA, isMonsterData, clearCache, monsterLibrary } from "./data.js";
import { EncounterBuilder, MonsterCreator, ActionBuilder } from "./apps.js";

const gmOnly = () => { if (game.user.isGM) return true; ui.notifications.warn(t("Only the GM can use the GM tools.")); return false; };
export const openEncounterBuilder = () => (gmOnly() ? EncounterBuilder.open() : null);
export const openMonsterCreator = (doc = null) => (gmOnly() ? MonsterCreator.open(doc) : null);

const { ApplicationV2 } = foundry.applications.api;
class EncounterMenu extends ApplicationV2 { async render() { openEncounterBuilder(); return this; } }
class CreatorMenu extends ApplicationV2 { async render() { openMonsterCreator(); return this; } }

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "houseRule", {
    name: t("House rule: Advancements raise party power"), scope: "world", config: true, type: Boolean, default: false,
    hint: game.i18n?.lang?.startsWith("it")
      ? "Non è nel manuale: ogni Avanzamento di un Campione aggiunge un po’ di forza al gruppo nel costruttore di scontri."
      : "Not in the rulebook: each Champion's Advancement adds a little party power in the encounter builder.",
  });
  game.settings.register(MODULE_ID, "advStep", {
    name: t("Power per Advancement"), scope: "world", config: true, type: Number, default: 0.1, range: { min: 0.05, max: 0.5, step: 0.05 },
    hint: game.i18n?.lang?.startsWith("it") ? "0,1 = ogni Avanzamento vale un decimo di Campione." : "0.1 = each Advancement is worth a tenth of a Champion.",
  });
  game.settings.register(MODULE_ID, "encounters", { scope: "world", config: false, type: Object, default: {} });
  game.settings.registerMenu(MODULE_ID, "encounterMenu", { name: t("Encounter builder"), label: t("Encounter builder"), icon: "fas fa-scale-balanced", type: EncounterMenu, restricted: true });
  game.settings.registerMenu(MODULE_ID, "creatorMenu", { name: t("Monster creator"), label: t("Monster creator"), icon: "fas fa-dragon", type: CreatorMenu, restricted: true });
});

Hooks.once("ready", () => {
  const mod = game.modules.get(MODULE_ID);
  if (mod) mod.api = { openEncounterBuilder, openMonsterCreator, buildAction: (row = null, list = "actions") => ActionBuilder.build(row, list), monsterLibrary, rules };
  if (game.user.isGM && !game.modules.get(TSA)?.active) ui.notifications.warn("Twilight Sword GM Tools needs the Twilight Sword Automation module.", { permanent: true });
});

/* the two buttons at the top of the Actors sidebar (GM only) */
Hooks.on("renderActorDirectory", (app, html) => {
  try {
    if (!game.user.isGM) return;
    const root = html instanceof HTMLElement ? html : html?.[0];
    if (!root || root.querySelector(".gmt-dir-buttons")) return;
    const box = document.createElement("div"); box.className = "gmt-dir-buttons";
    box.innerHTML = `<button type="button" data-gmt="enc"><i class="fas fa-scale-balanced"></i> ${t("Encounter builder")}</button>`
      + `<button type="button" data-gmt="crt"><i class="fas fa-dragon"></i> ${t("Monster creator")}</button>`;
    box.querySelector('[data-gmt="enc"]').addEventListener("click", ev => { ev.preventDefault(); openEncounterBuilder(); });
    box.querySelector('[data-gmt="crt"]').addEventListener("click", ev => { ev.preventDefault(); openMonsterCreator(); });
    const header = root.querySelector(".directory-header .header-actions") ?? root.querySelector(".directory-header") ?? root.querySelector("header");
    if (header) header.after(box); else root.prepend(box);
  } catch (e) { console.warn(`${MODULE_ID} | directory buttons`, e); }
});

/* right-click a Monster in the Actors sidebar → edit it in the creator */
function contextEntry() {
  const idOf = li => (li instanceof HTMLElement ? li : li?.[0])?.dataset?.entryId ?? (li instanceof HTMLElement ? li : li?.[0])?.dataset?.documentId;
  return {
    name: t("Edit in Monster creator"), label: t("Edit in Monster creator"), icon: '<i class="fas fa-dragon"></i>',
    condition: li => game.user.isGM && isMonsterData(game.actors.get(idOf(li))),
    callback: li => openMonsterCreator(game.actors.get(idOf(li))),
  };
}
for (const hook of ["getActorContextOptions", "getActorDirectoryEntryContext"]) {
  Hooks.on(hook, (app, options) => { try { if (Array.isArray(options)) options.push(contextEntry()); } catch (e) { /* ignore */ } });
}

/* the Monster lists are cached: refresh them when Monsters change */
for (const hook of ["createActor", "deleteActor", "updateActor"]) Hooks.on(hook, doc => { try { if (isMonsterData(doc)) clearCache(); } catch (e) { /* ignore */ } });
