/* Twilight Sword GM Tools — reading Monsters from the world and compendiums, writing homebrew Monsters, placing encounters. */
import { t, isItalian } from "./i18n.js";
import { num, isThreatX, draftFromProps, propsFromDraft, animFlags, applyVariant, statRanges } from "./rules.js";

export const MODULE_ID = "twilight-sword-gm-tools";
export const TSA = "twilight-sword-automation";
export const tsaApi = () => game.modules.get(TSA)?.api ?? null;

const props = doc => doc?.system?.props ?? {};
export const keyOf = doc => String(doc?.flags?.[TSA]?.key ?? doc?.name ?? "").toLowerCase();

/* ------------------------------------------------------------------ templates */
export function monsterTemplate() { return game.actors.find(a => a.type === "_template" && a.name === "Monster") ?? null; }
function templateNameOf(doc) {
  const id = doc?.system?.template; if (!id) return "";
  return game.actors.get(id)?.name ?? "";
}
/** A Monster: uses the Monster template, or has a Threat prop (compendium copies keep the world template id). */
export function isMonsterData(d) {
  if (!d || d.type === "_template") return false;
  const tid = d.system?.template, tpl = monsterTemplate();
  if (tpl && tid === tpl.id) return true;
  if (templateNameOf(d) === "Monster") return true;
  const p = d.system?.props ?? {};
  return "threat" in p && "m_die" in p;
}
async function reloadFromTemplate(doc) {
  const ts = doc?.templateSystem;
  try {
    if (ts && typeof ts.reloadTemplate === "function") await ts.reloadTemplate.call(ts);
    else if (typeof doc?.reloadTemplate === "function") await doc.reloadTemplate();
  } catch (e) { console.warn(`${MODULE_ID} | reload template`, doc?.name, e); }
}

/* ------------------------------------------------------------------ the Monster library */
const isItPack = pack => /(^|\.)ts-it-|\(it\)/i.test(`${pack.collection} ${pack.metadata?.label ?? ""}`);
let LIB = null, DOCS = null;
export function clearCache() { LIB = null; DOCS = null; }

/** Light list of every Monster: [{ uuid, name, img, threat, threatX, hearts, armor, stamina, lang, key, source }] */
export async function monsterLibrary() {
  if (LIB) return LIB;
  const out = [];
  for (const a of game.actors.filter(x => isMonsterData(x))) {
    const p = props(a);
    out.push({ uuid: a.uuid, name: a.name, img: a.img, threat: p.threat, threatX: isThreatX(p.threat, Object.values(p.mfeats ?? {}).map(f => f?.f_text)),
      hearts: num(p.hearts_max) || num(p.hearts), armor: num(p.armor), stamina: num(p.stamina), lang: a.getFlag(MODULE_ID, "lang") ?? null, key: keyOf(a),
      source: "world", homebrew: !!a.getFlag(MODULE_ID, "homebrew"), variant: a.getFlag(MODULE_ID, "variant") ?? null });
  }
  for (const pack of game.packs.filter(p => p.documentName === "Actor")) {
    let index;
    try { index = await pack.getIndex({ fields: ["system.template", "system.props.threat", "system.props.hearts", "system.props.hearts_max", "system.props.armor", "system.props.stamina", "system.props.m_die", `flags.${TSA}.key`] }); }
    catch (e) { continue; }
    for (const e of index) {
      if (!isMonsterData(e)) continue;
      const p = e.system?.props ?? {};
      out.push({ uuid: e.uuid ?? `Compendium.${pack.collection}.Actor.${e._id}`, name: e.name, img: e.img, threat: p.threat, threatX: String(p.threat ?? "").toUpperCase() === "X",
        hearts: num(p.hearts_max) || num(p.hearts), armor: num(p.armor), stamina: num(p.stamina), lang: isItPack(pack) ? "it" : "en",
        key: String(e.flags?.[TSA]?.key ?? e.name).toLowerCase(), source: "pack", pack: pack.metadata?.label ?? pack.collection });
    }
  }
  out.sort((a, b) => a.name.localeCompare(b.name));
  LIB = out;
  return out;
}
/** Monsters to offer in the current language (world Monsters without a language flag always show). */
export async function libraryForLanguage() {
  const lang = isItalian() ? "it" : "en";
  return (await monsterLibrary()).filter(m => !m.lang || m.lang === lang);
}
/** Full documents (actions, feats) for every Monster, grouped by key: { key: { en, it } }. */
export async function monsterDocs() {
  if (DOCS) return DOCS;
  const lib = await monsterLibrary();
  const docs = [];
  const packs = new Set(lib.filter(m => m.source === "pack").map(m => m.uuid.split(".").slice(1, 3).join(".")));
  for (const id of packs) {
    const pack = game.packs.get(id); if (!pack) continue;
    try { for (const d of await pack.getDocuments()) if (isMonsterData(d)) docs.push({ doc: d, lang: isItPack(pack) ? "it" : "en" }); } catch (e) { console.warn(`${MODULE_ID} | pack`, id, e); }
  }
  for (const a of game.actors.filter(x => isMonsterData(x))) docs.push({ doc: a, lang: a.getFlag(MODULE_ID, "lang") ?? (isItalian() ? "it" : "en") });
  const byKey = {};
  for (const { doc, lang } of docs) {
    const slot = (byKey[keyOf(doc)] ??= {});
    if (!slot[lang] || doc.pack) slot[lang] = doc;   // compendium content wins over world copies of the same Monster
  }
  DOCS = byKey;
  return byKey;
}
/** The other-language twin of a Monster document (same English key), or null. */
export async function twinOf(doc, lang) {
  const other = lang === "it" ? "en" : "it";
  const flagged = doc.getFlag?.(MODULE_ID, "twin");
  if (flagged) { const d = await fromUuid(flagged); if (d) return d; }
  return (await monsterDocs())[keyOf(doc)]?.[other] ?? null;
}
export function docLang(doc) {
  if (doc?.pack) return isItPack(game.packs.get(doc.pack) ?? { collection: doc.pack }) ? "it" : "en";
  return doc?.getFlag?.(MODULE_ID, "lang") ?? (isItalian() ? "it" : "en");
}
/** Stat ranges per Threat from the installed Monsters (English side, no duplicates). */
export async function liveRanges() {
  const lib = await monsterLibrary();
  const seen = new Set();
  const list = lib.filter(m => m.source === "pack" && m.lang === "en" && !m.threatX).filter(m => (seen.has(m.key) ? false : seen.add(m.key)));
  return list.length >= 10 ? statRanges(list) : null;
}

/* ------------------------------------------------------------------ writing actors */
async function folderFor(name, color = "#4b3570") {
  return game.folders.find(f => f.type === "Actor" && f.name === name && !f.folder) ?? await Folder.create({ name, type: "Actor", color });
}
/** Replace a CSB dynamic table: old rows marked $deleted, new rows under fresh keys. */
function tableReplace(oldRows, newRows) {
  const keys = Object.keys(oldRows ?? {});
  const start = keys.length ? Math.max(...keys.map(k => num(k))) + 1 : 0;
  const out = Object.fromEntries(keys.map(k => [k, { $deleted: true }]));
  Object.values(newRows).forEach((r, i) => { out[String(start + i)] = r; });
  return out;
}
function actorSource(draft, lang, tplId) {
  const p = propsFromDraft(draft, lang);
  const name = (lang === "it" ? draft.name.it : draft.name.en) || draft.name.en;
  return { name, type: "character", img: draft.img || "icons/svg/mystery-man.svg", system: { template: tplId, props: p },
    prototypeToken: { name, disposition: CONST.TOKEN_DISPOSITIONS.HOSTILE, actorLink: false } };
}
/**
 * Save a homebrew Monster in both languages. existing = { en: actor|null, it: actor|null }.
 * Returns { en, it } actors.
 */
export async function saveHomebrew(draft, existing = {}) {
  const tpl = monsterTemplate();
  if (!tpl) throw new Error(t("Import the Twilight Sword templates first (Monster template not found)."));
  const key = draft.name.en.trim();
  // every action number gets an entry: "" = let the automation module classify the action from its text
  const anim = Object.fromEntries([1, 2, 3, 4, 5, 6].map(n => [n, animFlags(draft)[n] ?? ""]));
  const flagsFor = lang => ({ [TSA]: { key, anim },
    [MODULE_ID]: { homebrew: true, lang, specs: { actions: draft.actions.map(r => r.spec ?? null), specials: draft.specials.map(r => r.spec ?? null) } } });
  const out = {};
  for (const lang of ["en", "it"]) {
    const src = actorSource(draft, lang, tpl.id);
    const cur = existing[lang] && !existing[lang].pack ? existing[lang] : null;
    if (cur) {
      const P = props(cur);
      const upd = { name: src.name, img: src.img, "prototypeToken.name": src.name };
      for (const [k, v] of Object.entries(src.system.props)) {
        upd[`system.props.${k}`] = ["actions", "specials", "mfeats"].includes(k) ? tableReplace(P[k], v) : v;
      }
      upd[`flags.${TSA}.key`] = key;
      upd[`flags.${TSA}.anim`] = anim;
      upd[`flags.${MODULE_ID}`] = flagsFor(lang)[MODULE_ID];
      await cur.update(upd);
      out[lang] = cur;
    } else {
      const folder = await folderFor(lang === "it" ? "Mostri homebrew (IT)" : "Homebrew Monsters", lang === "it" ? "#3b2d5c" : "#4b3570");
      const a = await Actor.create({ ...src, folder: folder.id, flags: flagsFor(lang) });
      await reloadFromTemplate(a);
      out[lang] = a;
    }
  }
  await out.en.setFlag(MODULE_ID, "twin", out.it.uuid);
  await out.it.setFlag(MODULE_ID, "twin", out.en.uuid);
  clearCache();
  return out;
}
/** Load a Monster (and its twin) as a draft. */
export async function draftFromActor(doc) {
  const lang = docLang(doc);
  const twin = await twinOf(doc, lang);
  const en = lang === "en" ? doc : twin, it = lang === "it" ? doc : twin;
  const d = draftFromProps(props(en ?? doc), it ? props(it) : null, { nameEn: (en ?? doc).name, nameIt: it?.name ?? "", img: doc.img });
  const anim = (en ?? doc).flags?.[TSA]?.anim ?? {};
  d.actions.forEach((r, i) => { r.anim = anim[i + 1] || anim[String(i + 1)] || "auto"; });
  const specs = (en ?? doc).getFlag?.(MODULE_ID, "specs");
  if (specs) { d.actions.forEach((r, i) => { r.spec = specs.actions?.[i] ?? null; }); d.specials.forEach((r, i) => { r.spec = specs.specials?.[i] ?? null; }); }
  return { draft: d, en, it };
}

/* ------------------------------------------------------------------ encounters: actors and tokens */
/** The world actor to place for a library Monster with a variant / element: reused if it was made before. */
async function deployActor(entry, pcs) {
  const source = await fromUuid(entry.uuid);
  if (!source) return null;
  const tag = `${entry.variant || "none"}|${entry.element || ""}`;
  if (tag === "none|" && !source.pack) return source;
  const existing = game.actors.find(a => a.getFlag(MODULE_ID, "from") === entry.uuid && a.getFlag(MODULE_ID, "variant") === tag);
  if (existing) return existing;
  const folder = await folderFor(isItalian() ? "Mostri degli scontri" : "Encounter Monsters", "#6f42a8");
  const data = source.toObject(); delete data._id; delete data.folder;
  if (tag !== "none|") {
    const lang = docLang(source);
    const d = draftFromProps(props(source), null, { nameEn: source.name, nameIt: source.name, img: source.img });
    applyVariant(d, { variant: entry.variant, element: entry.element, defense: entry.defense ?? "dodge", pcs });
    const p = propsFromDraft(d, lang);
    data.system.props = { ...data.system.props, ...p };
    data.name = d.name[lang] || d.name.en;
    data.prototypeToken = { ...(data.prototypeToken ?? {}), name: data.name };
    foundry.utils.setProperty(data, `flags.${TSA}.key`, `${keyOf(source)} (${tag})`);
  }
  data.folder = folder.id;
  foundry.utils.setProperty(data, `flags.${MODULE_ID}.from`, entry.uuid);
  foundry.utils.setProperty(data, `flags.${MODULE_ID}.variant`, tag);
  foundry.utils.setProperty(data, `flags.${MODULE_ID}.lang`, docLang(source));
  const a = await Actor.create(data);
  await reloadFromTemplate(a);
  clearCache();
  return a;
}
/** Place the encounter's Monsters around the centre of the current view; optionally add them to the combat. */
export async function deployEncounter(entries, { hidden = false, combat = false, pcs = 4 } = {}) {
  const scene = canvas?.scene;
  if (!scene) { ui.notifications.warn(t("Open a scene first.")); return []; }
  const g = scene.grid?.size ?? canvas.grid?.size ?? 100;
  const center = { x: canvas.stage.pivot.x, y: canvas.stage.pivot.y };
  const total = entries.reduce((s, e) => s + Math.max(0, num(e.count)), 0);
  const perRow = Math.max(1, Math.ceil(Math.sqrt(total)));
  const datas = [];
  let i = 0;
  for (const e of entries) {
    const actor = await deployActor(e, pcs);
    if (!actor) continue;
    for (let n = 0; n < Math.max(0, num(e.count)); n++, i++) {
      const w = actor.prototypeToken?.width ?? 1;
      const col = i % perRow, row = Math.floor(i / perRow);
      const x = Math.round((center.x - (perRow * g) / 2) / g) * g + col * g * Math.max(1, w);
      const y = Math.round((center.y - (perRow * g) / 2) / g) * g + row * g * Math.max(1, w);
      const td = await actor.getTokenDocument({ x, y, hidden });
      datas.push(td.toObject());
    }
  }
  const created = await scene.createEmbeddedDocuments("Token", datas);
  if (combat && created.length) {
    let c = game.combats.find(x => x.scene?.id === scene.id && x.active) ?? game.combats.find(x => x.scene?.id === scene.id);
    if (!c) c = await Combat.create({ scene: scene.id, active: true });
    await c.createEmbeddedDocuments("Combatant", created.map(tk => ({ tokenId: tk.id, sceneId: scene.id, actorId: tk.actorId, hidden })));
  }
  ui.notifications.info(t("Placed {n} tokens on the scene.", { n: created.length }));
  return created;
}

/* ------------------------------------------------------------------ the party */
export function championActors() {
  return game.actors.filter(a => templateNameOf(a) === "Champion" || ("hope" in props(a) && "way1" in props(a)));
}
export function partyActors() { return game.actors.filter(a => templateNameOf(a) === "Party"); }
export function advancementsOf(actor) {
  try { const s = tsaApi()?.advancementState?.(actor); if (s) return num(s.made); } catch (e) { /* fall back */ }
  return Math.floor(num(props(actor).hope) / 4);
}
