/* Twilight Sword GM Tools — the windows. */
import { t, isItalian } from "./i18n.js";
import { num, ELEMENTS, emptyDraft, applyVariant, buildActionText, automationPreview } from "./rules.js";
import { encounterView, creatorView, builderView, builderPreview, pickerView, actionChips } from "./views.js";
import { MODULE_ID, TSA, tsaApi, monsterLibrary, libraryForLanguage, monsterDocs, docLang, keyOf, liveRanges, saveHomebrew, draftFromActor,
  deployEncounter, championActors, partyActors, advancementsOf, clearCache } from "./data.js";

const { ApplicationV2, DialogV2 } = foundry.applications.api;
const props = d => d?.system?.props ?? {};
const live = rows => Object.entries(rows ?? {}).filter(([, r]) => r && !r.$deleted).sort((a, b) => num(a[0]) - num(b[0])).map(([, r]) => r);
const clone = o => foundry.utils.deepClone(o);
const animOf = (name, text) => { try { return tsaApi()?.monsterActionClass?.(name ?? "", text ?? "") ?? null; } catch (e) { return null; } };

export function isDark() {
  let s = "auto";
  try { s = game.settings.get(TSA, "sheetTheme"); } catch (e) { /* the automation module decides */ }
  if (s === "dark") return true;
  if (s === "light") return false;
  try { const cs = game.settings.get("core", "uiConfig")?.colorScheme?.applications; if (cs) return cs === "dark"; } catch (e) { /* older cores */ }
  return document.body.classList.contains("theme-dark");
}
const setting = (k, fb) => { try { return game.settings.get(MODULE_ID, k); } catch (e) { return fb; } };

/* ------------------------------------------------------------------ shared window behaviour */
class GMTApp extends ApplicationV2 {
  static DEFAULT_OPTIONS = { classes: ["gmt-app"], window: { resizable: true } };
  view() { return ""; }
  async _renderHTML() { return this.view(); }
  _replaceHTML(result, content) {
    // keep scroll positions and the focused field across re-renders
    const scrolls = {}; content.querySelectorAll("[data-scroll]").forEach(e => { scrolls[e.dataset.scroll] = e.scrollTop; });
    const act = document.activeElement, focus = content.contains(act) && act?.dataset?.f ? { f: act.dataset.f, s: act.selectionStart, e: act.selectionEnd } : null;
    content.innerHTML = result;
    content.querySelectorAll("[data-scroll]").forEach(e => { if (scrolls[e.dataset.scroll] != null) e.scrollTop = scrolls[e.dataset.scroll]; });
    if (focus) {
      const el = content.querySelector(`[data-f="${CSS.escape(focus.f)}"]`);
      if (el) { el.focus({ preventScroll: true }); try { if (focus.s != null && el.setSelectionRange) el.setSelectionRange(focus.s, focus.e); } catch (e) { /* number inputs */ } }
    }
    this.element?.classList.toggle("gmt-dark", isDark());
    this.element?.classList.toggle("gmt-light", !isDark());
  }
  _onFirstRender(context, options) {
    super._onFirstRender?.(context, options);
    const root = this.element;
    root.addEventListener("click", ev => {
      const a = ev.target.closest?.("[data-act]"); if (!a || !root.contains(a) || a.getAttribute("aria-disabled") === "true") return;
      ev.preventDefault(); this.onAct(a.dataset.act, a, ev);
    });
    const val = el => (el.type === "checkbox" ? el.checked : el.type === "number" ? (el.value === "" ? 0 : Number(el.value)) : el.value);
    root.addEventListener("change", ev => { const el = ev.target.closest?.("[data-f]"); if (el) this.onField(el.dataset.f, val(el), el, "change"); });
    root.addEventListener("input", ev => { const el = ev.target.closest?.("[data-f]"); if (el && el.type !== "checkbox" && el.tagName !== "SELECT") this.onField(el.dataset.f, val(el), el, "input"); });
    root.addEventListener("keydown", ev => { if (ev.key === "Enter" && ev.target.closest?.("[data-act]") && ev.target.tagName === "A") { ev.preventDefault(); ev.target.click(); } });
  }
  onAct() {}
  onField() {}
}
const confirm = (title, content, yes) => DialogV2.confirm({ window: { title }, content: `<p>${content}</p>`, yes: { label: yes ?? "OK" }, no: { label: t("Cancel") }, rejectClose: false, modal: true });

/* ------------------------------------------------------------------ picker: choose one thing from a searchable, grouped list */
export class Picker extends GMTApp {
  static DEFAULT_OPTIONS = { classes: ["gmt-app", "gmt-picker"], position: { width: 520, height: 600 } };
  constructor({ title, load, resolve }) { super({ window: { title, icon: "fas fa-book-skull" } }); this.state = { items: null, search: "" }; this.load = load; this.resolve = resolve; }
  static pick(title, load) { return new Promise(resolve => new Picker({ title, load, resolve }).render(true)); }
  view() { return pickerView(this.state); }
  async _onFirstRender(c, o) {
    super._onFirstRender(c, o);
    try { this.state.items = await this.load(); } catch (e) { console.error(e); this.state.items = []; }
    this.render();
  }
  onField(f, v) { if (f === "search") { this.state.search = v; this.render(); } }
  onAct(act, el) {
    if (act !== "pick") return;
    const item = this.state.items?.find(i => i.id === el.dataset.id);
    const r = this.resolve; this.resolve = null; r?.(item ?? null); this.close();
  }
  _onClose(o) { super._onClose?.(o); this.resolve?.(null); this.resolve = null; }
}

/* ------------------------------------------------------------------ encounter builder */
export class EncounterBuilder extends GMTApp {
  static DEFAULT_OPTIONS = { id: "gmt-encounter", classes: ["gmt-app", "gmt-encounter"], position: { width: 1040, height: 760 }, window: { icon: "fas fa-scale-balanced" } };
  static instance = null;
  static open() { (this.instance ??= new this()).render(true); this.instance.bringToFront?.(); return this.instance; }
  get title() { return t("Encounter builder"); }
  constructor() {
    super();
    this.state = { champions: [], allies: 0, entries: [], library: null, search: "", threatFilter: "", hidden: true, combat: true, savedId: "", saved: setting("encounters", {}),
      houseRule: !!setting("houseRule", false), step: num(setting("advStep", 0.1)) || 0.1, isGM: game.user.isGM };
    this.loadPartyQuiet();
    if (!this.state.champions.length) this.state.champions = [1, 2, 3, 4].map(n => ({ name: `${t("Champion")} ${n}`, adv: 0 }));
  }
  view() { return encounterView(this.state); }
  async _onFirstRender(c, o) {
    super._onFirstRender(c, o);
    this.element.addEventListener("dragover", ev => ev.preventDefault());
    this.element.addEventListener("drop", async ev => {
      const TE = foundry.applications?.ux?.TextEditor?.implementation ?? globalThis.TextEditor;
      const data = TE?.getDragEventData?.(ev) ?? {};
      if (data.type === "Actor" && data.uuid) { ev.preventDefault(); await this.addMonster(data.uuid); }
    });
    this.state.library = await libraryForLanguage();
    this.render();
  }
  _onClose(o) { super._onClose?.(o); EncounterBuilder.instance = null; }
  /** The party's Champions: the only Party sheet's members, or every Champion with a player. */
  loadPartyQuiet() {
    const parties = partyActors();
    let members = [];
    if (parties.length === 1) members = (parties[0].getFlag(TSA, "members") ?? []).map(u => fromUuidSync(u)).filter(a => a && "hope" in props(a));
    if (!members.length) members = championActors().filter(a => a.hasPlayerOwner);
    if (members.length) this.state.champions = members.map(a => ({ name: a.name, adv: advancementsOf(a), uuid: a.uuid }));
    return members.length;
  }
  async loadParty() {
    const parties = partyActors();
    let members = null;
    if (parties.length > 1) {
      const choice = await DialogV2.wait({ window: { title: t("Which party?") }, rejectClose: false, modal: true,
        buttons: [...parties.map(p => ({ action: p.id, label: p.name })), { action: "_all", label: t("All Champions with a player") }] });
      if (!choice) return;
      if (choice !== "_all") members = (game.actors.get(choice)?.getFlag(TSA, "members") ?? []).map(u => fromUuidSync(u)).filter(a => a && "hope" in props(a));
    } else if (parties.length === 1) members = (parties[0].getFlag(TSA, "members") ?? []).map(u => fromUuidSync(u)).filter(a => a && "hope" in props(a));
    if (!members?.length) members = championActors().filter(a => a.hasPlayerOwner);
    if (!members.length) return ui.notifications.warn(t("No Champions found."));
    this.state.champions = members.map(a => ({ name: a.name, adv: advancementsOf(a), uuid: a.uuid }));
    this.render();
  }
  async addMonster(uuid) {
    const s = this.state;
    const same = s.entries.find(e => e.uuid === uuid && e.variant === "none" && !e.element);
    if (same) { same.count = num(same.count) + 1; return this.render(); }
    let m = (s.library ?? []).find(x => x.uuid === uuid) ?? (await monsterLibrary()).find(x => x.uuid === uuid);
    if (!m) {
      const doc = await fromUuid(uuid); if (!doc || !("threat" in props(doc))) return;
      const p = props(doc);
      m = { uuid, name: doc.name, img: doc.img, threat: p.threat, threatX: String(p.threat).toUpperCase() === "X", hearts: num(p.hearts_max) || num(p.hearts), armor: num(p.armor) };
    }
    s.entries.push({ uuid: m.uuid, name: m.name, img: m.img, threat: m.threat, threatX: m.threatX, hearts: m.hearts, armor: m.armor, count: 1, variant: "none", element: "" });
    this.render();
  }
  async onField(f, v, el, kind) {
    const s = this.state, [a, i, k] = f.split(".");
    if (a === "search") { s.search = v; return this.render(); }
    if (kind === "input" && el.type !== "search") return;   // other fields update on change
    if (a === "champ") { s.champions[num(i)][k] = k === "adv" ? Math.max(0, num(v)) : v; }
    else if (a === "entry") { s.entries[num(i)][k] = k === "count" ? Math.max(0, num(v)) : v; }
    else if (a === "houseRule" || a === "step") {
      s[a] = a === "step" ? Math.max(0, num(v)) : !!v;
      if (game.user.isGM) await game.settings.set(MODULE_ID, a === "step" ? "advStep" : "houseRule", s[a]);
    } else s[a] = v;
    this.render();
  }
  async onAct(act, el) {
    const s = this.state, i = num(el.dataset.i);
    switch (act) {
      case "champ-add": s.champions.push({ name: `${t("Champion")} ${s.champions.length + 1}`, adv: s.champions.at(-1)?.adv ?? 0 }); break;
      case "champ-del": s.champions.splice(i, 1); break;
      case "load-party": return this.loadParty();
      case "lib-add": return this.addMonster(el.dataset.uuid);
      case "count": s.entries[i].count = Math.max(0, num(s.entries[i].count) + num(el.dataset.d)); break;
      case "entry-del": s.entries.splice(i, 1); break;
      case "clear": s.entries = []; break;
      case "enc-save": {
        const cur = s.saved[s.savedId];
        const name = await DialogV2.prompt({ window: { title: t("Save encounter") }, rejectClose: false, modal: true,
          content: `<label>${t("Encounter name")} <input type="text" name="n" value="${foundry.utils.escapeHTML(cur?.name ?? "")}" autofocus></label>`,
          ok: { label: t("Save encounter"), callback: (ev, btn) => btn.form.elements.n.value.trim() } });
        if (!name) return;
        const id = cur?.name === name ? s.savedId : foundry.utils.randomID();
        s.saved = { ...s.saved, [id]: { name, champions: clone(s.champions), allies: s.allies, entries: clone(s.entries) } };
        s.savedId = id;
        await game.settings.set(MODULE_ID, "encounters", s.saved);
        ui.notifications.info(t("Encounter saved."));
        break;
      }
      case "enc-load": { const e = s.saved[s.savedId]; if (!e) return; s.entries = clone(e.entries); if (e.champions?.length) s.champions = clone(e.champions); s.allies = num(e.allies); break; }
      case "enc-del": { const { [s.savedId]: _gone, ...rest } = s.saved; s.saved = rest; s.savedId = ""; await game.settings.set(MODULE_ID, "encounters", rest); break; }
      case "deploy": {
        const pcs = s.champions.length + num(s.allies);
        await deployEncounter(s.entries.filter(e => num(e.count) > 0), { hidden: s.hidden, combat: s.combat, pcs });
        clearCache(); s.library = await libraryForLanguage();
        break;
      }
      default: return;
    }
    this.render();
  }
}

/* ------------------------------------------------------------------ action builder */
export class ActionBuilder extends GMTApp {
  static DEFAULT_OPTIONS = { classes: ["gmt-app", "gmt-builder"], position: { width: 720, height: "auto" }, window: { icon: "fas fa-wand-magic-sparkles" } };
  get title() { return t("Action builder"); }
  constructor({ row, list, resolve }) {
    super();
    const spec = row?.spec ? clone(row.spec) : { mode: "attack", target: "close", dmg: row?.dmg && row.dmg !== "0" ? row.dmg : "1d8", status: "", dur: "", abil: "agl", self: "armor", armorBonus: 1, spell: "barrier" };
    this.b = { list, name: clone(row?.name ?? { en: "", it: "" }), hit: num(row?.hit), kind: row?.kind ?? "normal", stam: list === "specials" ? true : !!row?.stam, anim: row?.anim ?? "auto", spec };
    this.resolve = resolve;
  }
  static build(row, list) { return new Promise(resolve => new ActionBuilder({ row, list, resolve }).render(true)); }
  view() { return builderView(this.b, { animOf }); }
  refreshPreview() {
    const b = this.b, lang = isItalian() ? "it" : "en", txt = buildActionText(b.spec);
    const dmg = b.spec.mode === "attack" || b.spec.mode === "save" ? b.spec.dmg : "0";
    const chips = automationPreview({ name: b.name.en, text: txt[lang], hit: b.hit, dmg, color: b.kind }, lang, b.anim !== "auto" ? b.anim : animOf(b.name.en, txt.en));
    const box = this.element?.querySelector('[data-preview="builder"]'); if (box) box.innerHTML = builderPreview(b, txt, chips);
  }
  onField(f, v, el, kind) {
    const [a, k] = f.split(".");
    if (a === "spec") this.b.spec[k] = v; else if (a === "name") this.b.name[k] = v; else this.b[a] = a === "hit" ? num(v) : v;
    if (kind === "input") return this.refreshPreview();
    this.render();
  }
  onAct(act, el) {
    if (act === "mode") { this.b.spec.mode = el.dataset.mode; return this.render(); }
    if (act === "cancel") return this.close();
    if (act === "ok") {
      const b = this.b, txt = buildActionText(b.spec);
      const harm = b.spec.mode === "attack" || b.spec.mode === "save";
      const row = { name: { en: b.name.en.trim(), it: b.name.it.trim() || b.name.en.trim() }, hit: num(b.hit), dmg: harm && b.spec.dmg ? String(b.spec.dmg).toLowerCase() : "0",
        kind: b.kind, stam: b.list === "specials" ? true : !!b.stam, effect: txt, anim: b.anim, spec: clone(b.spec) };
      const r = this.resolve; this.resolve = null; r?.(row); this.close();
    }
  }
  _onClose(o) { super._onClose?.(o); this.resolve?.(null); this.resolve = null; }
}

/* ------------------------------------------------------------------ Monster creator */
const blankRow = list => (list === "feats" ? { name: { en: "", it: "" }, text: { en: "", it: "" } }
  : { name: { en: "", it: "" }, hit: 0, dmg: "0", kind: "normal", stam: list === "specials", effect: { en: "", it: "" }, anim: "auto", spec: null });

/** Rows of a Monster document as draft rows (both languages, from its twin). */
function rowFrom(kind, doc, twin, idx) {
  const P = props(doc), Q = props(twin ?? doc);
  if (kind === "a") {
    const a = live(P.actions)[idx]; const b = live(Q.actions).find(r => num(r.a_num) === num(a.a_num)) ?? a;
    const anim = ((docLang(doc) === "en" ? doc : twin) ?? doc)?.flags?.[TSA]?.anim?.[a.a_num] || "auto";
    return { a, b, row: { hit: num(a.a_hit), dmg: String(a.a_dmg ?? "0") || "0", kind: a.a_kind || "normal", stam: !!a.a_stam, anim }, n: "a_name", e: "a_effect" };
  }
  const a = live(P.specials)[idx], b = live(Q.specials)[idx] ?? a;
  return { a, b, row: { hit: num(a.s_hit), dmg: String(a.s_dmg ?? "0") || "0", kind: a.s_kind || "normal", stam: true, anim: "auto" }, n: "s_name", e: "s_effect" };
}

export class MonsterCreator extends GMTApp {
  static DEFAULT_OPTIONS = { id: "gmt-creator", classes: ["gmt-app", "gmt-creator"], position: { width: 900, height: 820 }, window: { icon: "fas fa-dragon" } };
  static instance = null;
  static async open(doc = null) {
    const app = (this.instance ??= new this());
    if (doc) await app.load(doc, { copy: !!doc.pack });
    app.render(true); app.bringToFront?.();
    return app;
  }
  get title() { return t("Monster creator"); }
  constructor() {
    super();
    this.state = { draft: emptyDraft(), lang: isItalian() ? "it" : "en", existing: {}, v: { variant: "none", element: "", defense: "dodge" }, dirty: false };
    this.ranges = null;
  }
  view() { return creatorView(this.state, { animOf, ranges: this.ranges }); }
  async _onFirstRender(c, o) { super._onFirstRender(c, o); this.ranges = await liveRanges(); this.render(); }
  _onClose(o) { super._onClose?.(o); MonsterCreator.instance = null; }

  async load(doc, { copy = false } = {}) {
    const { draft, en, it } = await draftFromActor(doc);
    if (copy) { draft.name = { en: `${draft.name.en} (${t("copy")})`, it: `${draft.name.it || draft.name.en} (${t("copy")})` }; }
    this.state.draft = draft;
    this.state.existing = copy ? {} : { en, it };
    this.state.dirty = copy;
  }
  row(el) { const box = el.closest("[data-list][data-i]"); return box ? { list: box.dataset.list, i: num(box.dataset.i) } : null; }
  updateChips(list, i) {
    if (list === "feats") return;
    const r = this.state.draft[list][i], lang = this.state.lang;
    const box = this.element?.querySelector(`[data-preview="${list}.${i}"]`);
    if (box) box.innerHTML = actionChips(r, lang, r.anim && r.anim !== "auto" ? r.anim : animOf(r.name.en || r.name[lang], r.effect.en || r.effect[lang]));
  }
  onField(f, v, el, kind) {
    const s = this.state, d = s.draft, parts = f.split(".");
    s.dirty = true;
    if (parts[0] === "v") { s.v[parts[1]] = v; return this.render(); }
    if (["name", "notes"].includes(f)) { d[f][s.lang] = v; return; }
    if (f === "affinity") { const el2 = ELEMENTS.find(e => e.id === v); if (v !== "_custom") d.affinity = el2 ? { en: el2.en, it: el2.it } : { en: "", it: "" }; return this.render(); }
    if (["threat", "hearts", "armor", "stamina", "die"].includes(f)) { d[f] = ["threat", "die"].includes(f) ? String(v) : Math.max(0, num(v)); return kind === "change" ? this.render() : null; }
    const [list, i, k] = parts, r = d[list]?.[num(i)]; if (!r) return;
    if (el.dataset.pair) r[k][s.lang] = v;
    else r[k] = k === "hit" ? num(v) : v;
    if (k === "effect") r.spec = null;   // edited by hand: the builder's settings no longer describe it
    if (k === "kind" && kind === "change") return this.render();
    this.updateChips(list, num(i));
  }
  async onAct(act, el) {
    const s = this.state, d = s.draft, at = this.row(el);
    const list = el.dataset.list ?? at?.list;
    switch (act) {
      case "lang": s.lang = el.dataset.lang; break;
      case "new":
        if (s.dirty && !(await confirm(t("New Monster"), t("Discard the current Monster?"), t("Discard")))) return;
        s.draft = emptyDraft(); s.existing = {}; s.dirty = false; break;
      case "open": case "copy": {
        if (s.dirty && !(await confirm(t(act === "open" ? "Open homebrew" : "Copy an existing Monster"), t("Discard the current Monster?"), t("Discard")))) return;
        const pick = await Picker.pick(t("Pick a Monster"), async () => {
          const lib = act === "open" ? (await monsterLibrary()).filter(m => m.homebrew && (!m.lang || m.lang === (isItalian() ? "it" : "en"))) : await libraryForLanguage();
          return lib.map(m => ({ id: m.uuid, label: m.name, group: act === "open" ? t("Homebrew") : `${t("Threat")} ${m.threatX ? "X" : num(m.threat)}`, text: `♥ ${m.hearts} · ${t("Armor")} ${m.armor}` }))
            .sort((a, b) => a.group.localeCompare(b.group, undefined, { numeric: true }));
        });
        if (!pick) return;
        const doc = await fromUuid(pick.id); if (!doc) return;
        await this.load(doc, { copy: act === "copy" });
        break;
      }
      case "img": {
        const FP = foundry.applications?.apps?.FilePicker?.implementation ?? globalThis.FilePicker;
        new FP({ type: "image", current: d.img, callback: path => { d.img = path; s.dirty = true; this.render(); } }).render(true);
        return;
      }
      case "variant": {
        applyVariant(d, { variant: s.v.variant, element: s.v.element, defense: s.v.defense, pcs: 4 });
        const label = [s.v.variant !== "none" ? t({ blue: "Blue", red: "Red", black: "Black" }[s.v.variant]) : "", ELEMENTS.find(e => e.id === s.v.element)?.[s.lang] ?? ""].filter(Boolean).join(" + ");
        ui.notifications.info(t("Variant applied: {v}. Check the texts.", { v: label }));
        s.v = { variant: "none", element: "", defense: "dodge" }; s.dirty = true;
        break;
      }
      case "add":
        if (list === "actions" && d.actions.length >= 6) return ui.notifications.warn(t("Up to 6 actions (the action die is a D6 at most)."));
        d[list].push(blankRow(list)); s.dirty = true; break;
      case "del": d[at.list].splice(at.i, 1); s.dirty = true; break;
      case "up": case "down": {
        const arr = d[at.list], j = at.i + (act === "up" ? -1 : 1);
        if (j < 0 || j >= arr.length) return;
        [arr[at.i], arr[j]] = [arr[j], arr[at.i]]; s.dirty = true; break;
      }
      case "build": {
        const row = await ActionBuilder.build(d[at.list][at.i], at.list);
        if (!row) return;
        d[at.list][at.i] = row; s.dirty = true; break;
      }
      case "build-new": {
        if (list === "actions" && d.actions.length >= 6) return ui.notifications.warn(t("Up to 6 actions (the action die is a D6 at most)."));
        const row = await ActionBuilder.build(null, list);
        if (!row) return;
        d[list].push(row); s.dirty = true; break;
      }
      case "lib-action": {
        if (list === "actions" && d.actions.length >= 6) return ui.notifications.warn(t("Up to 6 actions (the action die is a D6 at most)."));
        const row = await this.pickAction(); if (!row) return;
        if (list === "specials") row.stam = true;
        d[list].push(row); s.dirty = true; break;
      }
      case "lib-feat": { const f = await this.pickFeat(); if (!f) return; d.feats.push(f); s.dirty = true; break; }
      case "save": return this.save();
      default: return;
    }
    this.render();
  }
  /** Monsters in the editing language, with their twins, for the libraries. */
  async sourceDocs() {
    const byKey = await monsterDocs(), lang = this.state.lang, other = lang === "it" ? "en" : "it";
    return Object.values(byKey).filter(x => x[lang] || x[other]).map(x => ({ doc: x[lang] ?? x[other], twin: x[lang] ? x[other] ?? null : null, lang: x[lang] ? lang : other }))
      .sort((a, b) => a.doc.name.localeCompare(b.doc.name));
  }
  async pickAction() {
    const esc = foundry.utils.escapeHTML;
    let index = [];
    const pick = await Picker.pick(t("Pick an action"), async () => {
      const items = [];
      for (const { doc, twin } of await this.sourceDocs()) {
        live(props(doc).actions).forEach((r, i) => { index.push({ id: `${doc.uuid}|a|${i}`, doc, twin }); items.push({ id: `${doc.uuid}|a|${i}`, group: doc.name, label: `${r.a_num}. ${r.a_name}`,
          labelHtml: `<b>${esc(String(r.a_num))}. ${esc(r.a_name ?? "")}</b>${num(r.a_hit) ? ` [${num(r.a_hit)}]` : ""}${r.a_kind === "red" || r.a_kind === "blue" ? ` <span class="gmt-dot gmt-kind-${r.a_kind}"></span>` : ""}`, text: r.a_effect }); });
        live(props(doc).specials).forEach((r, i) => { index.push({ id: `${doc.uuid}|s|${i}`, doc, twin }); items.push({ id: `${doc.uuid}|s|${i}`, group: doc.name, label: `★ ${r.s_name}`,
          labelHtml: `<b><i class="fas fa-bolt"></i> ${esc(r.s_name ?? "")}</b>${num(r.s_hit) ? ` [${num(r.s_hit)}]` : ""}`, text: r.s_effect }); });
      }
      return items;
    });
    if (!pick) return null;
    const src = index.find(x => x.id === pick.id); if (!src) return null;
    const [, kind, idx] = pick.id.split("|");
    const { a, b, row, n, e } = rowFrom(kind, src.doc, src.twin, num(idx));
    const lang = docLang(src.doc);
    const nm = lang === "it" ? { en: b[n] ?? a[n], it: a[n] } : { en: a[n], it: b[n] ?? a[n] };
    const ef = lang === "it" ? { en: b[e] ?? a[e], it: a[e] } : { en: a[e], it: b[e] ?? a[e] };
    return { ...row, name: nm, effect: ef, spec: null };
  }
  async pickFeat() {
    let index = [];
    const pick = await Picker.pick(t("Pick a feat"), async () => {
      const items = [];
      for (const { doc, twin } of await this.sourceDocs()) live(props(doc).mfeats).forEach((r, i) => { index.push({ id: `${doc.uuid}|f|${i}`, doc, twin }); items.push({ id: `${doc.uuid}|f|${i}`, group: doc.name, label: r.f_name, text: r.f_text }); });
      return items;
    });
    if (!pick) return null;
    const src = index.find(x => x.id === pick.id); if (!src) return null;
    const i = num(pick.id.split("|")[2]);
    const a = live(props(src.doc).mfeats)[i], b = live(props(src.twin ?? src.doc).mfeats)[i] ?? a;
    const it = docLang(src.doc) === "it";
    return { name: { en: (it ? b : a).f_name, it: (it ? a : b).f_name }, text: { en: (it ? b : a).f_text, it: (it ? a : b).f_text } };
  }
  async save() {
    const s = this.state, d = s.draft;
    if (!d.name.en.trim()) { s.lang = "en"; this.render(); return ui.notifications.warn(t("Give the Monster an English name.")); }
    if (!d.name.it.trim() && !(await confirm(t("Save Monster"), t("The Italian version has no name: the English one will be used. Save anyway?"), t("Save anyway")))) return;
    const rows = [...d.actions.map(r => [r.name, r.effect]), ...d.specials.map(r => [r.name, r.effect]), ...d.feats.map(f => [f.name, f.text])].flat();
    if (d.name.it.trim() && rows.some(p => p.en.trim() && !p.it.trim()) && !(await confirm(t("Save Monster"), t("Some Italian texts are empty: the English text will be used for them. Save anyway?"), t("Save anyway")))) return;
    try {
      const out = await saveHomebrew(d, s.existing);
      s.existing = out; s.dirty = false;
      ui.notifications.info(t("Saved {name} (English and Italian).", { name: d.name[s.lang] || d.name.en }));
      this.render();
    } catch (e) { console.error(e); ui.notifications.error(e.message); }
  }
}
export { keyOf };
