/* Twilight Sword GM Tools — HTML for the windows (pure: state in, HTML out). */
import { t, esc, isItalian } from "./i18n.js";
import { num, ELEMENTS, ABILITIES, STATUSES, TARGETS, SPELLS, DURATIONS, ANIM_CLASSES, VARIANTS, BANDS, showDice, encounterSummary,
  automationPreview, buildActionText, effectiveThreat, compareToRange, RULEBOOK_RANGES } from "./rules.js";

const L = () => (isItalian() ? "it" : "en");
const fmt = n => (Math.round(n * 100) / 100).toLocaleString(isItalian() ? "it-IT" : "en-US");
const opt = (value, label, sel) => `<option value="${esc(value)}"${String(value) === String(sel) ? " selected" : ""}>${esc(label)}</option>`;
const skulls = (threat, x) => (x ? `<span class="gmt-threat gmt-threat-x" title="${esc(t("Threat"))} X">X</span>`
  : `<span class="gmt-threat" title="${esc(t("Threat"))} ${num(threat)}">${num(threat)}</span>`);
const chipList = chips => chips.map(c => `<span class="gmt-chip gmt-chip-${c.kind}">${esc(c.text)}</span>`).join("");

/* ------------------------------------------------------------------ encounter builder */
export function encounterView(s) {
  const sum = encounterSummary({ champions: s.champions, allies: s.allies, houseRule: s.houseRule, step: s.step,
    entries: s.entries.map(e => ({ threat: e.threat, threatX: e.threatX, variant: e.variant, count: e.count })) });
  const lang = L();
  const P = sum.party.power;

  // the gauge: rulebook bands drawn to scale, the encounter's Threat as a marker
  let gauge;
  if (!s.champions.length) gauge = `<p class="gmt-empty">${esc(t("Add at least one Champion."))}</p>`;
  else {
    const S = Math.max(P * 2, sum.total * 1.12, 1);
    const cuts = [0, 0.5 * P, P, 1.25 * P, 1.5 * P, S];
    const segs = BANDS.map((b, i) => `<div class="gmt-seg gmt-band-${b.id}${sum.band?.id === b.id ? " gmt-seg-on" : ""}" style="flex-basis:${((cuts[i + 1] - cuts[i]) / S) * 100}%"><span>${esc(t(b.label))}</span></div>`).join("");
    const ticks = [[P, `${fmt(P)}`], [1.5 * P, `${fmt(1.5 * P)}`]].map(([v, l]) => `<span class="gmt-tick" style="left:${(v / S) * 100}%">${esc(l)}</span>`).join("");
    const marker = sum.total > 0 ? `<div class="gmt-marker" style="left:${Math.min(100, (sum.total / S) * 100)}%"><b>${fmt(sum.total)}</b></div>` : "";
    const verdict = sum.band
      ? `<div class="gmt-verdict gmt-band-${sum.band.id}-text"><span class="gmt-verdict-word">${esc(t(sum.band.label))}</span><span class="gmt-verdict-sub">${esc(t("Collective Threat"))} <b>${fmt(sum.total)}</b> · ${esc(t("Party power"))} <b>${fmt(P)}</b></span></div>`
      : `<div class="gmt-verdict"><span class="gmt-verdict-sub">${esc(t("Add Monsters to rate the encounter."))}</span></div>`;
    gauge = `${verdict}<div class="gmt-gauge"><div class="gmt-bar">${segs}</div>${marker}<div class="gmt-ticks">${ticks}</div></div>`;
  }
  const notes = [];
  if (s.champions.length) notes.push({ key: "Rulebook: a collective Threat between {a} and {b} for this party.", vars: { a: fmt(sum.low), b: fmt(sum.high) } });
  if (sum.band?.id === "deadly") notes.push({ warn: true, key: "Over 1.5 × the Champions: extremely challenging, no guarantee the heroes prevail." });
  if (s.houseRule && s.champions.length) notes.push({ key: "House rule on: +{p}% power per Advancement (party power {x} instead of {n}).", vars: { p: Math.round(s.step * 100), x: fmt(P), n: sum.party.pcs } });
  if (sum.party.maxAdv >= 4) notes.push({ key: "Red and Black variants can appear now." });
  else if (sum.party.maxAdv >= 2) notes.push({ key: "Blue variants can appear now." });
  notes.push(...sum.notes);
  const notesHtml = notes.map(n => `<li class="${n.warn ? "gmt-warn" : ""}"><i class="fas ${n.warn ? "fa-triangle-exclamation" : "fa-circle-info"}"></i> ${esc(t(n.key, n.vars))}</li>`).join("");

  const champs = s.champions.map((c, i) => `<div class="gmt-champ">
      <input type="text" data-f="champ.${i}.name" value="${esc(c.name)}" aria-label="${esc(t("Champion"))}">
      <label class="gmt-adv" title="${esc(t("Advancements"))}"><i class="fas fa-sun"></i><input type="number" min="0" max="20" data-f="champ.${i}.adv" value="${num(c.adv)}"></label>
      <a class="gmt-icon" data-act="champ-del" data-i="${i}" title="${esc(t("Remove"))}"><i class="fas fa-xmark"></i></a></div>`).join("");

  const entries = s.entries.length ? s.entries.map((e, i) => {
    const eff = effectiveThreat({ threat: e.threat, threatX: e.threatX, variant: e.variant }, sum.party.pcs);
    const vHearts = variantHearts(e, sum.party.pcs);
    return `<div class="gmt-entry gmt-v-${e.variant}">
      <img src="${esc(e.img)}" alt="">
      <div class="gmt-entry-main"><span class="gmt-entry-name">${esc(e.name)}</span>
        <span class="gmt-entry-stats"><i class="fas fa-heart"></i> ${vHearts} <i class="fas fa-shield-halved"></i> ${num(e.armor) + (e.variant === "red" || e.variant === "black" ? 1 : 0)} ${skulls(e.threatX ? "X" : eff, e.threatX)}</span></div>
      <select data-f="entry.${i}.variant" aria-label="${esc(t("Variant"))}">${VARIANTS.map(v => opt(v.id, v.id === "none" ? t("Regular") : t({ blue: "Blue", red: "Red", black: "Black" }[v.id]), e.variant)).join("")}</select>
      <select data-f="entry.${i}.element" aria-label="${esc(t("Element"))}">${opt("", t("No element"), e.element)}${ELEMENTS.map(el => opt(el.id, el[lang], e.element)).join("")}</select>
      <div class="gmt-stepper"><a data-act="count" data-i="${i}" data-d="-1"><i class="fas fa-minus"></i></a><input type="number" min="0" data-f="entry.${i}.count" value="${num(e.count)}"><a data-act="count" data-i="${i}" data-d="1"><i class="fas fa-plus"></i></a></div>
      <span class="gmt-entry-sum">${fmt(eff * num(e.count))}</span>
      <a class="gmt-icon" data-act="entry-del" data-i="${i}" title="${esc(t("Remove"))}"><i class="fas fa-trash"></i></a></div>`;
  }).join("") : `<p class="gmt-empty">${esc(t("No Monsters yet. Pick some from the list on the right."))}</p>`;

  const q = s.search.trim().toLowerCase();
  const lib = (s.library ?? []).filter(m => (!q || m.name.toLowerCase().includes(q)) && (!s.threatFilter || (s.threatFilter === "X" ? m.threatX : String(num(m.threat)) === s.threatFilter && !m.threatX)));
  const libHtml = s.library === null ? `<p class="gmt-empty"><i class="fas fa-spinner fa-spin"></i> ${esc(t("Loading Monsters…"))}</p>`
    : lib.length ? lib.map(m => `<a class="gmt-lib-item" data-act="lib-add" data-uuid="${esc(m.uuid)}" draggable="false">
        <img src="${esc(m.img)}" alt=""><span class="gmt-lib-name">${esc(m.name)}${m.homebrew ? ` <em class="gmt-tag">${esc(t("Homebrew"))}</em>` : m.source === "world" ? ` <em class="gmt-tag">${esc(t("World Monsters"))}</em>` : ""}</span>
        <span class="gmt-lib-stats"><i class="fas fa-heart"></i>${num(m.hearts)} ${skulls(m.threat, m.threatX)}</span></a>`).join("")
    : `<p class="gmt-empty">${esc(t("No Monsters match."))}</p>`;
  const threats = [...new Set((s.library ?? []).filter(m => !m.threatX).map(m => num(m.threat)))].sort((a, b) => a - b);

  const saved = Object.entries(s.saved ?? {});
  return `<div class="gmt-enc">
    <section class="gmt-col gmt-col-main">
      <div class="gmt-panel gmt-party">
        <header><h2><i class="fas fa-users"></i> ${esc(t("Party"))}</h2>
          <a class="gmt-btn gmt-btn-quiet" data-act="load-party"><i class="fas fa-download"></i> ${esc(t("Load party"))}</a></header>
        <div class="gmt-champs">${champs}<a class="gmt-add" data-act="champ-add"><i class="fas fa-plus"></i> ${esc(t("Add champion"))}</a></div>
        <div class="gmt-party-foot">
          <label class="gmt-inline" title="${esc(t("NPC allies count as PCs"))}">${esc(t("NPC allies"))} <input type="number" min="0" data-f="allies" value="${num(s.allies)}"></label>
          <label class="gmt-inline gmt-toggle"><input type="checkbox" data-f="houseRule"${s.houseRule ? " checked" : ""}${s.isGM ? "" : " disabled"}> ${esc(t("House rule: Advancements raise party power"))}</label>
          ${s.houseRule ? `<label class="gmt-inline">${esc(t("Power per Advancement"))} <input type="number" step="0.05" min="0" max="1" data-f="step" value="${s.step}"${s.isGM ? "" : " disabled"}></label>` : ""}
        </div>
      </div>
      <div class="gmt-panel gmt-rating">${gauge}<ul class="gmt-notes">${notesHtml}</ul>
        <p class="gmt-fine">${esc(t("Bands below N and above 1.5N follow the rulebook; the split at 1.25N is an interpretation."))}</p></div>
      <div class="gmt-panel gmt-entries">
        <header><h2><i class="fas fa-skull"></i> ${esc(t("Encounter"))}</h2>${s.entries.length ? `<a class="gmt-btn gmt-btn-quiet" data-act="clear"><i class="fas fa-broom"></i> ${esc(t("Clear"))}</a>` : ""}</header>
        <div class="gmt-entry-list gmt-scroll" data-scroll="entries">${entries}</div>
      </div>
      <footer class="gmt-foot">
        <div class="gmt-saved">
          <select data-f="savedId" aria-label="${esc(t("Saved encounters"))}">${opt("", `— ${t("Saved encounters")} —`, s.savedId)}${saved.map(([id, e]) => opt(id, e.name, s.savedId)).join("")}</select>
          <a class="gmt-btn gmt-btn-quiet" data-act="enc-load"${s.savedId ? "" : " aria-disabled=\"true\""}>${esc(t("Load"))}</a>
          <a class="gmt-btn gmt-btn-quiet" data-act="enc-save"><i class="fas fa-floppy-disk"></i> ${esc(t("Save encounter"))}</a>
          ${s.savedId ? `<a class="gmt-icon" data-act="enc-del" title="${esc(t("Delete"))}"><i class="fas fa-trash"></i></a>` : ""}
        </div>
        <div class="gmt-deploy">
          <label class="gmt-inline"><input type="checkbox" data-f="hidden"${s.hidden ? " checked" : ""}> ${esc(t("Place hidden"))}</label>
          <label class="gmt-inline"><input type="checkbox" data-f="combat"${s.combat ? " checked" : ""}> ${esc(t("Add to combat"))}</label>
          <a class="gmt-btn gmt-btn-main" data-act="deploy"${s.entries.length ? "" : " aria-disabled=\"true\""}><i class="fas fa-chess-board"></i> ${esc(t("Place on scene"))}</a>
        </div>
      </footer>
    </section>
    <section class="gmt-col gmt-col-lib">
      <div class="gmt-lib-tools">
        <input type="search" data-f="search" value="${esc(s.search)}" placeholder="${esc(t("Search Monsters"))}" aria-label="${esc(t("Search Monsters"))}">
        <select data-f="threatFilter" aria-label="${esc(t("Threat"))}">${opt("", t("All Threat"), s.threatFilter)}${threats.map(n => opt(n, `${t("Threat")} ${n}`, s.threatFilter)).join("")}${(s.library ?? []).some(m => m.threatX) ? opt("X", `${t("Threat")} X`, s.threatFilter) : ""}</select>
      </div>
      <p class="gmt-fine">${esc(t("Click a Monster to add it, or drag one from the Actors sidebar."))}</p>
      <div class="gmt-lib gmt-scroll" data-scroll="lib">${libHtml}</div>
    </section>
  </div>`;
}
export function variantHearts(e, pcs) {
  const T = e.threatX ? pcs : num(e.threat), h = num(e.hearts);
  return e.variant === "blue" ? h + 3 * T : e.variant === "red" ? h + 5 * T : e.variant === "black" ? h * 2 : h;
}

/* ------------------------------------------------------------------ Monster creator */
const kindSelect = (path, v) => `<select data-f="${path}.kind" class="gmt-kind gmt-kind-${esc(v)}" aria-label="${esc(t("Color"))}">${opt("normal", t("Normal"), v)}${opt("red", t("Red: can’t be parried"), v)}${opt("blue", t("Blue: can’t be dodged"), v)}</select>`;
const animSelect = (path, v) => `<select data-f="${path}.anim" aria-label="${esc(t("Animation"))}">${opt("auto", t("Automatic"), v)}${ANIM_CLASSES.map(c => opt(c, c, v)).join("")}</select>`;

export function actionChips(row, lang, animClass) {
  return chipList(automationPreview({ name: row.name[lang] || row.name.en, text: row.effect[lang] || "", hit: row.hit, dmg: row.dmg, color: row.kind }, lang, animClass));
}
function actionRow(list, r, i, lang, n, animOf) {
  const path = `${list}.${i}`;
  const special = list === "specials";
  const cls = r.anim && r.anim !== "auto" ? r.anim : animOf(r.name.en || r.name[lang], r.effect.en || r.effect[lang]);
  return `<div class="gmt-act gmt-kindrow-${esc(r.kind)}" data-list="${list}" data-i="${i}">
    <div class="gmt-act-head">
      ${special ? `<span class="gmt-num gmt-num-special" title="${esc(t("Costs 1 Stamina"))}"><i class="fas fa-bolt"></i></span>` : `<span class="gmt-num">${i + 1}</span>`}
      <input type="text" class="gmt-act-name" data-f="${path}.name" data-pair="1" value="${esc(r.name[lang])}" placeholder="${esc(lang === "it" ? r.name.en : t("Name"))}" aria-label="${esc(t("Name"))}">
      <label class="gmt-mini" title="${esc(t("D12 to hit: {n} or lower", { n: "N" }))}">${esc(t("Hit"))}<input type="number" min="0" max="12" data-f="${path}.hit" value="${num(r.hit)}"></label>
      <label class="gmt-mini gmt-mini-wide">${esc(t("Damage"))}<input type="text" data-f="${path}.dmg" value="${esc(r.dmg)}" placeholder="1d8"></label>
      ${kindSelect(path, r.kind)}
      ${special ? "" : `<label class="gmt-mini gmt-check" title="${esc(t("Costs 1 Stamina"))}"><i class="fas fa-bolt"></i><input type="checkbox" data-f="${path}.stam"${r.stam ? " checked" : ""}></label>`}
      ${special ? "" : animSelect(path, r.anim)}
      <span class="gmt-row-tools">
        <a class="gmt-icon gmt-build" data-act="build" title="${esc(t("Action builder"))}"><i class="fas fa-wand-magic-sparkles"></i></a>
        <a class="gmt-icon" data-act="up" title="↑"><i class="fas fa-arrow-up"></i></a>
        <a class="gmt-icon" data-act="down" title="↓"><i class="fas fa-arrow-down"></i></a>
        <a class="gmt-icon" data-act="del" title="${esc(t("Remove"))}"><i class="fas fa-trash"></i></a>
      </span>
    </div>
    <textarea data-f="${path}.effect" data-pair="1" rows="2" placeholder="${esc(lang === "it" && r.effect.en ? r.effect.en : t("Effect text"))}" aria-label="${esc(t("Effect text"))}">${esc(r.effect[lang])}</textarea>
    <div class="gmt-chips" data-preview="${path}">${actionChips(r, lang, cls)}</div>
  </div>`;
}

export function creatorView(s, { animOf = () => null, ranges = null } = {}) {
  const d = s.draft, lang = s.lang;
  const R = ranges ?? RULEBOOK_RANGES;
  const tnum = /^x$/i.test(String(d.threat)) ? null : num(d.threat);
  const rg = tnum ? R[tnum] : null;
  const guide = (stat, v) => {
    if (!rg) return "";
    const r = rg[stat], c = compareToRange(v, r);
    return `<span class="gmt-guide gmt-guide-${c}" title="${esc(t("Threat {t} Monsters", { t: tnum }))}: ${r[0]}–${r[2]}">${r[0]}–${r[2]}${c === "high" ? ` <i class="fas fa-arrow-up"></i>` : c === "low" ? ` <i class="fas fa-arrow-down"></i>` : ""}</span>`;
  };
  const warns = [];
  const nA = d.actions.length;
  if (nA && nA !== num(d.die)) warns.push(t("Action die D{d}: {n} actions (expected {d}).", { d: d.die, n: nA }));
  if (d.specials.length && !num(d.stamina)) warns.push(t("Special actions cost 1 Stamina: give the Monster some Stamina."));
  if (!rg && tnum) warns.push(t("No published Monsters with this Threat: compare with Bosses."));

  const affSel = ELEMENTS.find(e => e.en === d.affinity.en || e.it === d.affinity.it)?.id ?? (d.affinity.en ? "_custom" : "");
  const sideLang = lang === "it" ? "en" : "it";
  return `<div class="gmt-crt">
    <div class="gmt-toolbar">
      <a class="gmt-btn gmt-btn-quiet" data-act="new"><i class="fas fa-file"></i> ${esc(t("New Monster"))}</a>
      <a class="gmt-btn gmt-btn-quiet" data-act="open"><i class="fas fa-folder-open"></i> ${esc(t("Open homebrew"))}</a>
      <a class="gmt-btn gmt-btn-quiet" data-act="copy"><i class="fas fa-clone"></i> ${esc(t("Copy an existing Monster"))}</a>
      <div class="gmt-lang" role="group" aria-label="${esc(t("Editing"))}">
        <span>${esc(t("Editing"))}</span>
        <a data-act="lang" data-lang="en" class="${lang === "en" ? "on" : ""}" aria-pressed="${lang === "en"}">EN</a>
        <a data-act="lang" data-lang="it" class="${lang === "it" ? "on" : ""}" aria-pressed="${lang === "it"}">IT</a>
      </div>
      <a class="gmt-btn gmt-btn-main" data-act="save"><i class="fas fa-floppy-disk"></i> ${esc(t("Save Monster"))}</a>
    </div>
    <div class="gmt-crt-body gmt-scroll" data-scroll="crt">
      <div class="gmt-identity">
        <a class="gmt-portrait" data-act="img" title="${esc(t("Image"))}"><img src="${esc(d.img)}" alt=""></a>
        <div class="gmt-id-main">
          <input type="text" class="gmt-mname" data-f="name" data-pair="1" value="${esc(d.name[lang])}" placeholder="${esc(lang === "it" && d.name.en ? d.name.en : t("Name"))}" aria-label="${esc(t("Name"))}">
          ${lang === "it" && d.name.en ? `<span class="gmt-twin">EN: ${esc(d.name.en)}</span>` : lang === "en" && d.name.it ? `<span class="gmt-twin">IT: ${esc(d.name.it)}</span>` : ""}
          <div class="gmt-stats">
            <label class="gmt-stat gmt-stat-threat"><span>${esc(t("Threat"))}</span><select data-f="threat">${[1, 2, 3, 4, 5, 6].map(n => opt(n, n, d.threat)).join("")}${opt("X", "X", String(d.threat).toUpperCase())}</select></label>
            <label class="gmt-stat"><span><i class="fas fa-heart"></i> ${esc(t("Hearts"))}</span><input type="number" min="1" data-f="hearts" value="${num(d.hearts)}">${guide("hearts", d.hearts)}</label>
            <label class="gmt-stat"><span><i class="fas fa-shield-halved"></i> ${esc(t("Armor"))}</span><input type="number" min="0" data-f="armor" value="${num(d.armor)}">${guide("armor", d.armor)}</label>
            <label class="gmt-stat"><span><i class="fas fa-bolt"></i> ${esc(t("Stamina"))}</span><input type="number" min="0" data-f="stamina" value="${num(d.stamina)}">${guide("stamina", d.stamina)}</label>
            <label class="gmt-stat"><span><i class="fas fa-dice-d6"></i> ${esc(t("Action die"))}</span><select data-f="die">${opt("4", "D4", d.die)}${opt("6", "D6", d.die)}</select></label>
            <label class="gmt-stat"><span>${esc(t("Affinity"))}</span><select data-f="affinity">${opt("", t("None"), affSel)}${ELEMENTS.map(e => opt(e.id, e[lang], affSel)).join("")}${affSel === "_custom" ? opt("_custom", d.affinity[lang] || d.affinity.en, affSel) : ""}</select></label>
          </div>
          <p class="gmt-fine">${esc(ranges ? t("Guidance from your Monster compendium") : t("Guidance from the rulebook’s Monsters"))}: ${esc(t("The rulebook has no rules for building Monsters from scratch. These ranges come from the published Monsters with the same Threat."))}</p>
        </div>
      </div>
      ${warns.length ? `<ul class="gmt-notes">${warns.map(w => `<li class="gmt-warn"><i class="fas fa-triangle-exclamation"></i> ${esc(w)}</li>`).join("")}</ul>` : ""}
      <div class="gmt-variantbar">
        <span class="gmt-variant-label"><i class="fas fa-palette"></i> ${esc(t("Make variant"))}</span>
        <select data-f="v.variant" aria-label="${esc(t("Variant"))}">${VARIANTS.map(v => opt(v.id, v.id === "none" ? `— ${t("Variant")} —` : t({ blue: "Blue", red: "Red", black: "Black" }[v.id]), s.v.variant)).join("")}</select>
        <select data-f="v.element" aria-label="${esc(t("Element"))}">${opt("", t("No element"), s.v.element)}${ELEMENTS.map(e => opt(e.id, e[lang], s.v.element)).join("")}</select>
        ${s.v.variant === "black" ? `<select data-f="v.defense" aria-label="${esc(t("Black variant defense"))}">${opt("dodge", t("Dodge [8]"), s.v.defense)}${opt("parry", t("Parry [8]"), s.v.defense)}</select>` : ""}
        <a class="gmt-btn gmt-btn-quiet" data-act="variant"${s.v.variant === "none" && !s.v.element ? " aria-disabled=\"true\"" : ""}>${esc(t("Apply"))}</a>
      </div>
      <section class="gmt-sec">
        <header><h2><i class="fas fa-dice-d6"></i> ${esc(t("Actions"))} <small>D${esc(d.die)}</small></h2>
          <span><a class="gmt-btn gmt-btn-quiet" data-act="lib-action" data-list="actions"><i class="fas fa-book-skull"></i> ${esc(t("From another Monster"))}</a>
          <a class="gmt-btn gmt-btn-quiet" data-act="build-new" data-list="actions"><i class="fas fa-wand-magic-sparkles"></i> ${esc(t("Build"))}</a>
          <a class="gmt-btn gmt-btn-quiet" data-act="add" data-list="actions"${nA >= 6 ? ` aria-disabled="true" title="${esc(t("Up to 6 actions (the action die is a D6 at most)."))}"` : ""}><i class="fas fa-plus"></i> ${esc(t("Add action"))}</a></span></header>
        ${d.actions.map((r, i) => actionRow("actions", r, i, lang, i + 1, animOf)).join("") || `<p class="gmt-empty">—</p>`}
      </section>
      <section class="gmt-sec">
        <header><h2><i class="fas fa-star"></i> ${esc(t("Special actions"))} <small><i class="fas fa-bolt"></i> 1</small></h2>
          <span><a class="gmt-btn gmt-btn-quiet" data-act="lib-action" data-list="specials"><i class="fas fa-book-skull"></i> ${esc(t("From another Monster"))}</a>
          <a class="gmt-btn gmt-btn-quiet" data-act="build-new" data-list="specials"><i class="fas fa-wand-magic-sparkles"></i> ${esc(t("Build"))}</a>
          <a class="gmt-btn gmt-btn-quiet" data-act="add" data-list="specials"><i class="fas fa-plus"></i> ${esc(t("Add special action"))}</a></span></header>
        ${d.specials.map((r, i) => actionRow("specials", r, i, lang, 0, animOf)).join("") || `<p class="gmt-empty">—</p>`}
      </section>
      <section class="gmt-sec">
        <header><h2><i class="fas fa-scroll"></i> ${esc(t("Feats"))}</h2>
          <span><a class="gmt-btn gmt-btn-quiet" data-act="lib-feat"><i class="fas fa-book-skull"></i> ${esc(t("From another Monster"))}</a>
          <a class="gmt-btn gmt-btn-quiet" data-act="add" data-list="feats"><i class="fas fa-plus"></i> ${esc(t("Add feat"))}</a></span></header>
        ${d.feats.map((f, i) => `<div class="gmt-feat" data-list="feats" data-i="${i}">
            <input type="text" data-f="feats.${i}.name" data-pair="1" value="${esc(f.name[lang])}" placeholder="${esc(lang === "it" && f.name.en ? f.name.en : t("Name"))}" aria-label="${esc(t("Name"))}">
            <textarea data-f="feats.${i}.text" data-pair="1" rows="1" placeholder="${esc(lang === "it" && f.text.en ? f.text.en : t("Feat text"))}" aria-label="${esc(t("Feat text"))}">${esc(f.text[lang])}</textarea>
            <span class="gmt-row-tools"><a class="gmt-icon" data-act="up"><i class="fas fa-arrow-up"></i></a><a class="gmt-icon" data-act="down"><i class="fas fa-arrow-down"></i></a><a class="gmt-icon" data-act="del" title="${esc(t("Remove"))}"><i class="fas fa-trash"></i></a></span>
          </div>`).join("") || `<p class="gmt-empty">—</p>`}
      </section>
      <section class="gmt-sec">
        <header><h2><i class="fas fa-feather"></i> ${esc(t("Notes"))}</h2></header>
        <textarea data-f="notes" data-pair="1" rows="3" aria-label="${esc(t("Notes"))}">${esc(d.notes[lang])}</textarea>
      </section>
      <p class="gmt-fine gmt-side">${sideLang === "it" ? "IT" : "EN"}: ${esc(d.name[sideLang] || "—")}</p>
    </div>
  </div>`;
}

/* ------------------------------------------------------------------ action builder */
export function builderView(b, { animOf = () => null } = {}) {
  const sp = b.spec, lang = L();
  const txt = buildActionText(sp);
  const dmg = sp.mode === "attack" || sp.mode === "save" ? sp.dmg : "0";
  const chips = automationPreview({ name: b.name.en, text: txt[lang], hit: b.hit, dmg, color: b.kind }, lang, b.anim !== "auto" ? b.anim : animOf(b.name.en, txt.en));
  const modes = [["attack", "Attack", "Damage and/or a status on the target", "fa-burst"], ["save", "Ability roll", "The target must pass a roll or suffer the effect", "fa-dice-d20"],
    ["self", "Self", "A defensive effect on the Monster", "fa-shield"], ["spell", "Spell", "The Monster casts a spell", "fa-hat-wizard"]];
  const harm = sp.mode === "attack" || sp.mode === "save";
  const field = (label, inner, cls = "") => `<label class="gmt-field ${cls}"><span>${esc(t(label))}</span>${inner}</label>`;
  return `<div class="gmt-bld">
    <div class="gmt-modes" role="radiogroup" aria-label="${esc(t("What does it do?"))}">${modes.map(([id, l, h, ic]) => `<a class="gmt-mode${sp.mode === id ? " on" : ""}" data-act="mode" data-mode="${id}" role="radio" aria-checked="${sp.mode === id}"><i class="fas ${ic}"></i><b>${esc(t(l))}</b><small>${esc(t(h))}</small></a>`).join("")}</div>
    <div class="gmt-bld-grid">
      ${field("Action name (English)", `<input type="text" data-f="name.en" value="${esc(b.name.en)}">`)}
      ${field("Action name (Italian)", `<input type="text" data-f="name.it" value="${esc(b.name.it)}">`)}
      ${harm ? field("Target", `<select data-f="spec.target">${TARGETS.map(x => opt(x.id, x[lang], sp.target)).join("")}</select>`) : ""}
      ${sp.mode === "save" ? field("Ability", `<select data-f="spec.abil">${ABILITIES.map(x => opt(x.id, x[lang], sp.abil)).join("")}</select>`) : ""}
      ${sp.mode === "save" ? field("Opposed roll", `<input type="checkbox" data-f="spec.opposed"${sp.opposed ? " checked" : ""}>`, "gmt-field-check") : ""}
      ${harm ? field("Damage", `<input type="text" data-f="spec.dmg" value="${esc(sp.dmg)}" placeholder="1d8">`) : ""}
      ${harm ? field("Element", `<select data-f="spec.element">${opt("", t("None"), sp.element)}${ELEMENTS.map(x => opt(x.id, x[lang], sp.element)).join("")}</select>`) : ""}
      ${harm ? field("Ignoring Armor", `<input type="checkbox" data-f="spec.ignoreArmor"${sp.ignoreArmor ? " checked" : ""}>`, "gmt-field-check") : ""}
      ${harm ? field("Status", `<select data-f="spec.status">${opt("", t("None"), sp.status)}${STATUSES.map(x => opt(x.id, x[lang], sp.status)).join("")}</select>`) : ""}
      ${harm && sp.status && sp.status !== "ko" ? field("Duration", `<select data-f="spec.dur">${DURATIONS.map(x => opt(x, x ? `${x} Round` : t("Until removed"), sp.dur)).join("")}</select>`) : ""}
      ${harm ? field("Knock prone", `<input type="checkbox" data-f="spec.prone"${sp.prone ? " checked" : ""}>`, "gmt-field-check") : ""}
      ${harm ? field("Push Near", `<input type="checkbox" data-f="spec.push"${sp.push ? " checked" : ""}>`, "gmt-field-check") : ""}
      ${sp.mode === "self" ? field("Effect on the Monster", `<select data-f="spec.self">${opt("armor", t("+ Armor until its next Turn"), sp.self)}${opt("shield", t("Avoid all damage until its next Turn"), sp.self)}${opt("burrow", t("Can’t be attacked until its next Turn"), sp.self)}</select>`, "gmt-field-wide") : ""}
      ${sp.mode === "self" && (sp.self ?? "armor") === "armor" ? field("Armor bonus", `<input type="number" min="1" max="5" data-f="spec.armorBonus" value="${num(sp.armorBonus) || 1}">`) : ""}
      ${sp.mode === "spell" ? field("Spell", `<select data-f="spec.spell">${SPELLS.map(x => opt(x.id, x[lang], sp.spell)).join("")}</select>`) : ""}
      ${field("Hit", `<input type="number" min="0" max="12" data-f="hit" value="${num(b.hit)}">`)}
      ${field("Color", `<select data-f="kind">${opt("normal", t("Normal"), b.kind)}${opt("red", t("Red: can’t be parried"), b.kind)}${opt("blue", t("Blue: can’t be dodged"), b.kind)}</select>`)}
      ${b.list === "actions" ? field("Costs 1 Stamina", `<input type="checkbox" data-f="stam"${b.stam ? " checked" : ""}>`, "gmt-field-check") : ""}
      ${b.list === "actions" ? field("Animation", `<select data-f="anim">${opt("auto", t("Automatic"), b.anim)}${ANIM_CLASSES.map(c => opt(c, c, b.anim)).join("")}</select>`) : ""}
      ${field("Extra text (English)", `<input type="text" data-f="spec.extraEn" value="${esc(sp.extraEn ?? "")}" title="${esc(t("Not automated: shown on the card for the GM."))}">`, "gmt-field-wide")}
      ${field("Extra text (Italian)", `<input type="text" data-f="spec.extraIt" value="${esc(sp.extraIt ?? "")}" title="${esc(t("Not automated: shown on the card for the GM."))}">`, "gmt-field-wide")}
    </div>
    <div class="gmt-bld-preview" data-preview="builder">${builderPreview(b, txt, chips)}</div>
    <footer class="gmt-bld-foot"><a class="gmt-btn gmt-btn-quiet" data-act="cancel">${esc(t("Cancel"))}</a><a class="gmt-btn gmt-btn-main" data-act="ok"><i class="fas fa-check"></i> ${esc(t("Use this action"))}</a></footer>
  </div>`;
}
export function builderPreview(b, txt, chips) {
  const card = lang => `<div class="gmt-card"><span class="gmt-card-lang">${lang.toUpperCase()}</span><b class="gmt-card-name gmt-kind-${esc(b.kind)}">${esc(b.name[lang] || b.name.en || "…")}${num(b.hit) ? ` [${num(b.hit)}]` : ""}</b>: ${esc(txt[lang] || "…")}</div>`;
  return `<h3>${esc(t("Preview"))}</h3>${card("en")}${card("it")}<h3>${esc(t("What will be automated"))}</h3><div class="gmt-chips">${chipList(chips)}</div>`;
}

/* ------------------------------------------------------------------ picker */
export function pickerView(p) {
  const q = p.search.trim().toLowerCase();
  const groups = {};
  for (const it of p.items) if (!q || `${it.label} ${it.group} ${it.text ?? ""}`.toLowerCase().includes(q)) (groups[it.group] ??= []).push(it);
  const body = Object.entries(groups).map(([g, items]) => `<div class="gmt-pick-group"><h3>${esc(g)}</h3>${items.map(it => `<a class="gmt-pick-item" data-act="pick" data-id="${esc(it.id)}">
      <span class="gmt-pick-label">${it.labelHtml ?? esc(it.label)}</span>${it.text ? `<span class="gmt-pick-text">${esc(it.text)}</span>` : ""}</a>`).join("")}</div>`).join("");
  return `<div class="gmt-pick">
    <input type="search" data-f="search" value="${esc(p.search)}" placeholder="${esc(t("Search"))}" aria-label="${esc(t("Search"))}" autofocus>
    <div class="gmt-pick-list gmt-scroll" data-scroll="pick">${p.items === null ? `<p class="gmt-empty"><i class="fas fa-spinner fa-spin"></i> ${esc(t("Loading Monsters…"))}</p>` : body || `<p class="gmt-empty">${esc(t("No Monsters match."))}</p>`}</div>
  </div>`;
}
export { showDice };
