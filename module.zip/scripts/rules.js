/* Twilight Sword GM Tools — pure rules logic (no Foundry globals at import time, unit-tested in Node). */

export const num = v => Number(v) || 0;

/* ------------------------------------------------------------------ vocabulary (English / Italian) */
export const ELEMENTS = [
  { id: "fire", en: "Fire", it: "Fuoco" }, { id: "ice", en: "Ice", it: "Ghiaccio" }, { id: "wind", en: "Wind", it: "Vento" },
  { id: "earth", en: "Earth", it: "Terra" }, { id: "thunder", en: "Thunder", it: "Fulmine" }, { id: "water", en: "Water", it: "Acqua" },
  { id: "light", en: "Light", it: "Luce" }, { id: "darkness", en: "Darkness", it: "Oscurità" },
];
export const ABILITIES = [
  { id: "str", en: "Strength", it: "Forza" }, { id: "agl", en: "Agility", it: "Agilità" }, { id: "vit", en: "Vitality", it: "Vitalità" },
  { id: "per", en: "Perception", it: "Percezione" }, { id: "wil", en: "Will", it: "Volontà" }, { id: "kno", en: "Knowledge", it: "Sapere" },
  { id: "cha", en: "Charisma", it: "Carisma" }, { id: "ste", en: "Stealth", it: "Furtività" },
];
export const STATUSES = [
  { id: "poison", en: "Poison", it: "Veleno" }, { id: "stun", en: "Stun", it: "Stordimento" }, { id: "confusion", en: "Confusion", it: "Confusione" },
  { id: "wound", en: "Wound", it: "Ferita" }, { id: "fear", en: "Fear", it: "Paura" }, { id: "freeze", en: "Freeze", it: "Gelo" },
  { id: "blind", en: "Blind", it: "Cecità" }, { id: "silence", en: "Silence", it: "Silenzio" }, { id: "burn", en: "Burn", it: "Ustione" },
  { id: "ko", en: "K.O.", it: "K.O." },
];
/** Targets as written on the Monster cards. pl = plural (Italian verbs agree). */
export const TARGETS = [
  { id: "close", en: "a Close PC", it: "un PG in Mischia", pl: false },
  { id: "near", en: "a PC within Near", it: "un PG entro Vicino", pl: false },
  { id: "far", en: "a PC within Far", it: "un PG entro Lontano", pl: false },
  { id: "mostHearts", en: "the Close PC with the most Hearts", it: "il PG in Mischia con più Cuori", pl: false },
  { id: "fewestHearts", en: "the PC within Near with the fewest Hearts", it: "il PG entro Vicino con meno Cuori", pl: false },
  { id: "farthest", en: "the farthest PC", it: "il PG più lontano", pl: false },
  { id: "allClose", en: "all Close PCs", it: "tutti i PG in Mischia", pl: true },
  { id: "allNear", en: "all PCs within Near", it: "tutti i PG entro Vicino", pl: true },
];
export const SPELLS = [
  { id: "sleep", en: "Sleep", it: "Sonno" }, { id: "stasis", en: "Stasis", it: "Stasi" }, { id: "clones", en: "Magic Clones", it: "Cloni Magici" },
  { id: "invisibility", en: "Invisibility", it: "Invisibilità" }, { id: "barrier", en: "Barrier", it: "Barriera" }, { id: "command", en: "Command", it: "Comando" },
  { id: "blinding", en: "Blinding Light", it: "Luce Abbagliante" }, { id: "lightspear", en: "Light Spear", it: "Lancia di Luce" },
  { id: "magicarmor", en: "Magic Armor", it: "Armatura Magica" },
];
export const DURATIONS = ["", "1", "2", "3", "1D4", "1D6", "2D4"];
/** Animation classes of the automation module (ANIM_CLASS keys). */
export const ANIM_CLASSES = ["breath", "frostbreath", "fire", "frost", "lightning", "spores", "poison", "sound", "hex", "sleep", "boulder", "shards", "arrow",
  "magic", "explosion", "teleport", "heal", "bite", "claw", "pierce", "pincer", "weapon", "sweep", "blow", "charge", "quake", "storm", "ink", "water",
  "guard", "burrow", "none"];

const cap = s => (s ? s[0].toUpperCase() + s.slice(1) : s);
const byId = (list, id) => list.find(x => x.id === id) ?? null;

/* ------------------------------------------------------------------ dice */
/** "1d6" + 1 -> "1d6+1"; "1d6+1" + 2 -> "1d6+3"; "2d6-1" + 1 -> "2d6". Lowercase d, as the sheet expects. */
export function addDamageBonus(formula, bonus) {
  const f = String(formula ?? "").trim().toLowerCase().replace(/\s+/g, "");
  if (!f || f === "0" || !bonus) return f || "0";
  const m = /^(.*?)([+-]\d+)?$/.exec(f);
  const total = num(m[2]) + bonus;
  return `${m[1]}${total > 0 ? `+${total}` : total < 0 ? total : ""}`;
}
export const showDice = f => String(f ?? "").toUpperCase().replace(/\s+/g, "");
const diceCore = f => (/(\d*)d(\d+)/i.exec(String(f ?? "")) ?? []).slice(1).join("d").toLowerCase();

/** Replace, in a card text, the first written damage dice matching the row's formula ("1D6" -> "1D6+1"). */
export function bumpDiceInText(text, oldFormula, newFormula) {
  const core = diceCore(oldFormula); if (!core) return text;
  const [n, d] = core.split("d");
  const re = new RegExp(`\\b${n || "1"}D${d}(?:\\s*[+-]\\s*\\d+)?(?![\\d])`, "i");
  return String(text ?? "").replace(re, showDice(newFormula));
}
/** "Deal 1D6 damage" -> "Deal 1D6 Fire damage"; Italian "1D6 danni" -> "1D6 danni da Fuoco". Already elemental damage is left alone. */
export function elementalizeText(text, el, lang) {
  const s = String(text ?? "");
  if (!el) return s;
  if (lang === "it") return s.replace(/(\d*D\d+(?:\s*[+-]\s*\d+)?)\s+danni(?!\s+da\s)/gi, `$1 danni da ${el.it}`);
  return s.replace(/(\d*D\d+(?:\s*[+-]\s*\d+)?)\s+damage/gi, `$1 ${el.en} damage`);
}

/* ------------------------------------------------------------------ encounter balance (Core Rulebook p. 164) */
export const BANDS = [
  { id: "trivial", label: "Trivial", upTo: 0.5 },
  { id: "easy", label: "Easy", upTo: 1, strict: true },
  { id: "balanced", label: "Balanced", upTo: 1.25 },
  { id: "hard", label: "Hard", upTo: 1.5 },
  { id: "deadly", label: "Deadly", upTo: Infinity },
];
/** Party power: 1 per Champion and per NPC ally (they count as PCs). House rule: each Champion's Advancements add `step` each. */
export function partyPower({ champions = [], allies = 0, houseRule = false, step = 0.1 } = {}) {
  const pcs = champions.length + Math.max(0, num(allies));
  const champPower = champions.reduce((s, c) => s + 1 + (houseRule ? Math.max(0, num(c.adv)) * num(step) : 0), 0);
  return { pcs, power: Math.round((champPower + Math.max(0, num(allies))) * 100) / 100, maxAdv: champions.reduce((m, c) => Math.max(m, num(c.adv)), 0) };
}
/** Threat X (or "Threat equal to the number of PCs" in a feat). */
export function isThreatX(threat, featTexts = []) {
  if (String(threat ?? "").trim().toUpperCase() === "X") return true;
  return featTexts.some(f => /threat is equal to the number of (?:pcs|champions)|minaccia (?:è )?pari al numero dei (?:pg|campioni)/i.test(String(f ?? "")));
}
/** One Monster's Threat in this encounter: X counts as the PCs; Black variants add +1 (never to Threat X). */
export function effectiveThreat({ threat, threatX = false, variant = "none" }, pcs) {
  if (threatX) return pcs;
  return Math.max(0, num(threat)) + (variant === "black" ? 1 : 0);
}
export function rateEncounter(totalThreat, power) {
  if (!(power > 0) || !(totalThreat > 0)) return { ratio: 0, band: null };
  const ratio = totalThreat / power;
  const band = BANDS.find(b => (b.strict ? ratio < b.upTo : ratio <= b.upTo + 1e-9));
  return { ratio, band };
}
/** Everything the encounter window shows. entries: [{threat, threatX, variant, count}] */
export function encounterSummary({ champions, allies, houseRule, step, entries }) {
  const party = partyPower({ champions, allies, houseRule, step });
  const total = entries.reduce((s, e) => s + effectiveThreat(e, party.pcs) * Math.max(0, num(e.count)), 0);
  const rating = rateEncounter(total, party.power);
  const notes = [];
  const has = v => entries.some(e => num(e.count) > 0 && e.variant === v);
  if (has("blue") && party.maxAdv < 2) notes.push({ warn: true, key: "Blue variants normally appear from HOPE 8 (2 Advancements)." });
  if ((has("red") || has("black")) && party.maxAdv < 4) notes.push({ warn: true, key: "Red and Black variants normally appear from HOPE 16 (4 Advancements)." });
  if (entries.some(e => e.threatX && num(e.count) > 0)) notes.push({ key: "Threat X counts as the number of PCs ({n}).", vars: { n: party.pcs } });
  if (entries.some(e => e.threatX && e.variant === "black" && num(e.count) > 0)) notes.push({ warn: true, key: "A Boss with Threat X cannot gain Threat." });
  return { party, total, ...rating, low: party.pcs, high: Math.round(party.pcs * 1.5 * 100) / 100, notes };
}

/* ------------------------------------------------------------------ Monster drafts (both languages side by side) */
const pair = (en = "", it = "") => ({ en: String(en ?? ""), it: String(it ?? "") });
const live = rows => Object.entries(rows ?? {}).filter(([, r]) => r && !r.$deleted).sort((a, b) => num(a[0]) - num(b[0])).map(([, r]) => r);

/** A draft from one or two Monster actors' props (English and Italian twins). */
export function draftFromProps(en, it = null, { nameEn = "", nameIt = "", img = "" } = {}) {
  const E = en ?? {}, I = it ?? en ?? {};
  const ea = live(E.actions).sort((a, b) => num(a.a_num) - num(b.a_num)), ia = live(I.actions).sort((a, b) => num(a.a_num) - num(b.a_num));
  const es = live(E.specials), is = live(I.specials), ef = live(E.mfeats), iff = live(I.mfeats);
  const twinA = r => ia.find(x => num(x.a_num) === num(r.a_num)) ?? r;
  return {
    name: pair(nameEn, nameIt || nameEn), img,
    threat: String(E.threat ?? "1"), hearts: num(E.hearts_max) || num(E.hearts), armor: num(E.armor), stamina: num(E.stamina),
    die: String(E.m_die ?? "6") === "4" ? "4" : "6",
    affinity: pair(E.affinity, I.affinity), notes: pair(E.m_notes, I.m_notes),
    actions: ea.map(r => ({ name: pair(r.a_name, twinA(r).a_name), hit: num(r.a_hit), dmg: String(r.a_dmg ?? "0") || "0", kind: r.a_kind || "normal",
      stam: !!r.a_stam, effect: pair(r.a_effect, twinA(r).a_effect), anim: "auto", spec: null })),
    specials: es.map((r, i) => ({ name: pair(r.s_name, is[i]?.s_name ?? r.s_name), hit: num(r.s_hit), dmg: String(r.s_dmg ?? "0") || "0", kind: r.s_kind || "normal",
      stam: r.s_stam === undefined ? true : !!r.s_stam, effect: pair(r.s_effect, is[i]?.s_effect ?? r.s_effect), anim: "auto", spec: null })),
    feats: ef.map((r, i) => ({ name: pair(r.f_name, iff[i]?.f_name ?? r.f_name), text: pair(r.f_text, iff[i]?.f_text ?? r.f_text) })),
  };
}
export function emptyDraft() {
  return { name: pair(), img: "icons/svg/mystery-man.svg", threat: "1", hearts: 10, armor: 0, stamina: 0, die: "6", affinity: pair(), notes: pair(), actions: [], specials: [], feats: [] };
}
/** Props for the Monster template in one language. Table rows keyed "0", "1", … (start lets an update use fresh keys). */
export function propsFromDraft(d, lang, start = 0) {
  const L = p => (p?.[lang] || p?.en || "");
  const table = (rows, fn) => Object.fromEntries(rows.map((r, i) => [String(start + i), fn(r, i)]));
  return {
    threat: /^x$/i.test(String(d.threat).trim()) ? "X" : num(d.threat), hearts: num(d.hearts), hearts_max: num(d.hearts), armor: num(d.armor), stamina: num(d.stamina),
    m_die: d.die === "4" ? "4" : "6", affinity: L(d.affinity), m_notes: L(d.notes),
    actions: table(d.actions, (r, i) => ({ a_num: i + 1, a_name: L(r.name), a_hit: num(r.hit), a_dmg: String(r.dmg || "0").toLowerCase(), a_kind: r.kind || "normal", a_effect: L(r.effect), a_stam: !!r.stam })),
    specials: table(d.specials, r => ({ s_name: L(r.name), s_hit: num(r.hit), s_dmg: String(r.dmg || "0").toLowerCase(), s_kind: r.kind || "normal", s_effect: L(r.effect), s_stam: r.stam !== false })),
    mfeats: table(d.feats, r => ({ f_name: L(r.name), f_text: L(r.text) })),
  };
}
/** Stored animation choices: { actionNumber: class } for rows that don't use the automatic one. */
export function animFlags(d) {
  return Object.fromEntries(d.actions.map((r, i) => [i + 1, r.anim]).filter(([, c]) => c && c !== "auto"));
}

/* ------------------------------------------------------------------ variants (Core Rulebook p. 182) */
export const VARIANTS = [
  { id: "none", en: "", it: "" }, { id: "blue", en: "Blue", it: "Blu" }, { id: "red", en: "Red", it: "Rosso" }, { id: "black", en: "Black", it: "Nero" },
];
export function variantName(name, variant, elementId) {
  const v = byId(VARIANTS, variant), el = byId(ELEMENTS, elementId);
  const en = [v?.en, el?.en, name.en].filter(Boolean).join(" ");
  const it = [name.it || name.en, el ? `di ${el.it}` : "", v?.it].filter(Boolean).join(" ");
  return { en, it };
}
/** Apply a variant (and/or an element) to a draft, in place. pcs = number of PCs, used for Threat X. */
export function applyVariant(d, { variant = "none", element = "", defense = "dodge", pcs = 4 } = {}) {
  const el = byId(ELEMENTS, element);
  const threatX = /^x$/i.test(String(d.threat).trim()) || isThreatX(d.threat, d.feats.map(f => f.text.en));
  const T = threatX ? pcs : num(d.threat);
  let bonus = 0;
  if (variant === "blue") { d.hearts = num(d.hearts) + 3 * T; bonus = 1; }
  if (variant === "red") { d.hearts = num(d.hearts) + 5 * T; bonus = 1; d.armor = num(d.armor) + 1; }
  if (variant === "black") {
    d.hearts = num(d.hearts) * 2; bonus = 2; d.armor = num(d.armor) + 1;
    if (!threatX) d.threat = String(num(d.threat) + 1);
    const nm = { en: d.name.en.toLowerCase(), it: (d.name.it || d.name.en).toLowerCase() };
    d.feats.unshift(defense === "parry"
      ? { name: pair("PARRY [8]", "PARATA [8]"), text: pair(`The ${nm.en} can parry an attack per Round`, `Il ${nm.it} può parare un attacco per Round`) }
      : { name: pair("DODGE [8]", "SCHIVATA [8]"), text: pair(`The ${nm.en} can dodge an attack per Round`, `Il ${nm.it} può schivare un attacco per Round`) });
  }
  for (const r of [...d.actions, ...d.specials]) {
    if (bonus && r.dmg && r.dmg !== "0") {
      const nf = addDamageBonus(r.dmg, bonus);
      r.effect = pair(bumpDiceInText(r.effect.en, r.dmg, nf), bumpDiceInText(r.effect.it, r.dmg, nf));
      r.dmg = nf;
    }
    if (el) r.effect = pair(elementalizeText(r.effect.en, el, "en"), elementalizeText(r.effect.it, el, "it"));
  }
  if (el) d.affinity = pair(el.en, el.it);
  d.name = variantName(d.name, variant, element);
  return d;
}

/* ------------------------------------------------------------------ action builder: card text the automation module can read */
const an = word => (/^[aeiou]/i.test(word) ? "an" : "a");
const itTo = target => (target.startsWith("il ") ? `al ${target.slice(3)}` : `a ${target}`);
/**
 * spec: { mode: attack|save|self|spell, target, dmg, element, ignoreArmor, status, dur, prone, push,
 *         abil, opposed, self: armor|shield|burrow, armorBonus, spell, extraEn, extraIt }
 * returns { en, it } effect texts.
 */
export function buildActionText(spec) {
  const s = { target: "close", dmg: "", status: "", dur: "", ...spec };
  const tg = byId(TARGETS, s.target) ?? TARGETS[0];
  const el = byId(ELEMENTS, s.element), st = byId(STATUSES, s.status), ab = byId(ABILITIES, s.abil) ?? ABILITIES[0];
  const D = showDice(s.dmg && s.dmg !== "0" ? s.dmg : "");
  const durEn = st && s.dur && st.id !== "ko" ? ` for ${s.dur} Round${s.dur === "1" ? "" : "s"}` : "";
  const durIt = st && s.dur && st.id !== "ko" ? ` per ${s.dur} Round` : "";
  let en = "", it = "";
  if (s.mode === "attack") {
    if (D) {
      en = `Deal ${D} ${el ? `${el.en} ` : ""}damage${s.ignoreArmor ? " (ignoring Armor)" : ""} to ${tg.en}.`;
      it = `Infliggi ${D} danni${el ? ` da ${el.it}` : ""}${s.ignoreArmor ? " (ignora l’Armatura)" : ""} ${itTo(tg.it)}.`;
      if (st) { en += ` They suffer ${st.en}${durEn}.`; it += ` ${tg.pl ? "Subiscono" : "Subisce"} ${st.it}${durIt}.`; }
    } else if (st) {
      en = `${cap(tg.en)} ${tg.pl ? "suffer" : "suffers"} ${st.en}${durEn}.`;
      it = `${cap(tg.it)} ${tg.pl ? "subiscono" : "subisce"} ${st.it}${durIt}.`;
    }
    if (s.prone) { en += `${en ? " " : ""}They are knocked prone.`; it += `${it ? " " : ""}${tg.pl ? "Vengono gettati proni." : "Viene gettato prono."}`; }
    if (s.push) { en += `${en ? " " : ""}They are pushed Near.`; it += `${it ? " " : ""}${tg.pl ? "Vengono spinti entro Vicino." : "Viene spinto entro Vicino."}`; }
  } else if (s.mode === "save") {
    const ce = [], ci = [];
    const harm = [];
    if (D) { ce.push(`take ${D} ${el ? `${el.en} ` : ""}damage${s.ignoreArmor ? " (ignoring Armor)" : ""}`); harm.push(`${D} danni${el ? ` da ${el.it}` : ""}${s.ignoreArmor ? " (ignora l’Armatura)" : ""}`); }
    if (st) { ce.push(`suffer ${st.en}${durEn}`); harm.push(`${st.it}${durIt}`); }
    if (harm.length) ci.push(`subire ${harm.join(" e ")}`);
    if (s.prone) { ce.push("be knocked prone"); ci.push(tg.pl ? "essere gettati proni" : "essere gettato prono"); }
    if (s.push) { ce.push("be pushed Near"); ci.push(tg.pl ? "essere spinti entro Vicino" : "essere spinto entro Vicino"); }
    const join = (arr, and) => (arr.length < 2 ? arr.join("") : `${arr.slice(0, -1).join(", ")} ${and === "e" && /^e/i.test(arr.at(-1)) ? "ed" : and} ${arr.at(-1)}`);
    const w = s.opposed ? "opposed" : ab.en;
    en = `${cap(tg.en)} must pass ${an(w)} ${s.opposed ? "opposed " : ""}${ab.en} roll${ce.length ? ` or ${join(ce, "and")}` : ""}.`;
    it = `${cap(tg.it)} ${tg.pl ? "devono" : "deve"} superare un tiro di ${ab.it}${s.opposed ? " contrapposto" : ""}${ci.length ? ` o ${join(ci, "e")}` : ""}.`;
  } else if (s.mode === "self") {
    if (s.self === "shield") { en = "Avoid all damage until your next Turn."; it = "Evita tutti i danni fino al tuo prossimo Turno."; }
    else if (s.self === "burrow") { en = "You can't be attacked until your next Turn."; it = "Non puoi essere attaccato fino al tuo prossimo Turno."; }
    else { const n = Math.max(1, num(s.armorBonus) || 1); en = `Gain +${n} Armor until your next Turn.`; it = `Ottieni +${n} Armatura fino al tuo prossimo Turno.`; }
  } else if (s.mode === "spell") {
    const sp = byId(SPELLS, s.spell) ?? SPELLS[0];
    en = `Cast ${sp.en}.`; it = `Lancia ${sp.it}.`;
  }
  if (s.extraEn) en = `${en} ${String(s.extraEn).trim()}`.trim();
  if (s.extraIt) it = `${it} ${String(s.extraIt).trim()}`.trim();
  return { en, it };
}

/* ------------------------------------------------------------------ automation preview: mirrors the readers in twilight-sword-automation 0.29 */
export function parseStatuses(text) {
  const DEFS = [
    ["poison", /\b(?:poison(?:ed)?|veleno|avvelenat[oaie])\b/i], ["stun", /\b(?:stun(?:ned)?|stordimento|stordit[oaie])\b/i], ["confusion", /\b(?:confusion|confusione)\b/i],
    ["wound", /\b(?:wound|ferita)\b/i], ["fear", /\b(?:fear|paura)\b/i], ["freeze", /\b(?:freeze|frozen|gelo|congelat[oaie])\b/i],
    ["blind", /\b(?:blind(?:ed)?\b|cecit[àa](?![a-z]))/i], ["silence", /\b(?:silence(?:d)?|silenzio)\b/i], ["burn", /\b(?:burn|ustione)\b/i],
    ["ko", /K\.O\./], ["prone", /\b(?:prone|pron[oaie])\b/i],
  ];
  const found = [];
  for (const [id, re] of DEFS) {
    const m = re.exec(text);
    if (!m) continue;
    const before = text.slice(Math.max(0, m.index - 24), m.index).toLowerCase();
    if (/(remove|not |resist|immune|\(not|other than|cure |rimuov|cura |immun|non |tranne)/.test(before)) continue;
    const after = text.slice(m.index, m.index + 70);
    const d = /(?:for|per)\s+(\d*\s*d\s*\d+(?:\s*[+-]\s*\d+)?|\d+)\s+(?:rounds?|turni)/i.exec(after);
    found.push({ id, duration: d ? d[1].replace(/\s+/g, "").toLowerCase().replace(/^d/, "1d") : null });
  }
  return found;
}
const ABILITY_KEYS = { strength: "str", agility: "agl", vitality: "vit", perception: "per", will: "wil", knowledge: "kno", charisma: "cha", stealth: "ste" };
export function parseSave(text) {
  const it = /(?:(?:deve|devono)\s+(?:superare|superer[àa]|passare)|non\s+supera(?:no)?|effettua(?:no)?)\s+un\s+tiro\s+(contrapposto\s+)?di\s+(Forza|Agilit[àa]|Vitalit[àa]|Percezione|Volont[àa]|Sapere|Carisma|Furtivit[àa])(\s+contrapposto)?(\s+con\s+Svantaggio)?/i.exec(text);
  if (it) {
    const w = it[2].toLowerCase();
    const en = w.startsWith("forz") ? "Strength" : w.startsWith("agil") ? "Agility" : w.startsWith("vital") ? "Vitality" : w.startsWith("perc") ? "Perception" : w.startsWith("volont") ? "Will" : w.startsWith("sap") ? "Knowledge" : w.startsWith("caris") ? "Charisma" : "Stealth";
    return { abil: ABILITY_KEYS[en.toLowerCase()], label: en, opposed: !!(it[1] || it[3]), dis: !!it[4] };
  }
  const m = /(?:must pass|don.t pass|doesn.t pass|pass)\s+an?\s+(opposed\s+)?(Strength|Agility|Vitality|Perception|Will|Knowledge|Charisma|Stealth)\s+roll(\s+(?:with|at)\s+(?:a\s+)?Disadvantage)?/i.exec(text);
  if (!m) return null;
  return { abil: ABILITY_KEYS[m[2].toLowerCase()], label: m[2][0].toUpperCase() + m[2].slice(1).toLowerCase(), opposed: !!m[1], dis: !!m[3] };
}
const MON_SPELLS = { sleep: ["sleep", "target"], sonno: ["sleep", "target"], stasis: ["stasis", "target"], stasi: ["stasis", "target"], "magic clones": ["clones", "self"], "cloni magici": ["clones", "self"],
  invisibility: ["invisible", "self"], "invisibilità": ["invisible", "self"], barrier: ["barrier", "self"], barriera: ["barrier", "self"], command: ["commanded", "target"], comando: ["commanded", "target"],
  "blinding light": ["dazzled", "target"], "luce abbagliante": ["dazzled", "target"], "light spear": ["marked", "target"], "lancia di luce": ["marked", "target"], "magic armor": ["magicarmor", "self"], "armatura magica": ["magicarmor", "self"] };
export function monsterActionEffects(name, text) {
  const t = `${name}. ${text}`.replace(/\s+/g, " "), out = [];
  const arm = /(?:gain|ottieni|ottiene)\s+\+(\d+)\s+(?:armor|armatura)\s+(?:until|fino)/i.exec(t);
  if (arm) out.push({ id: "guarded", who: "self", armor: Number(arm[1]), untilNextTurn: true });
  if (/avoid all damage until|evita tutti i danni fi ?no|cannot take damage|non puoi subire danni/i.test(t)) out.push({ id: "shelled", who: "self", untilNextTurn: true });
  if (/can.t be attacked until|non puoi essere attaccat/i.test(t)) out.push({ id: "burrowed", who: "self", untilNextTurn: true });
  const cast = /(?:^|\. )(?:cast|lancia)\s+([A-Za-zàèéìòù ]+?)(?:\.|$)/i.exec(t);
  const sp = MON_SPELLS[String(cast?.[1] ?? "").trim().toLowerCase()] ?? MON_SPELLS[String(name).trim().toLowerCase()];
  if (sp) out.push({ id: sp[0], who: sp[1] });
  return out;
}
export const ignoresArmor = text => /\bignor(?:e|es|ing)\b|\bignora(?:no|ndo)?\s+l[’']\s*Armatura/i.test(String(text ?? ""));

const SELF_LABEL = { guarded: { en: "Guarded (+{a} Armor)", it: "In guardia (+{a} Armatura)" }, shelled: { en: "No damage", it: "Nessun danno" }, burrowed: { en: "Burrowed", it: "Sottoterra" },
  sleep: { en: "Asleep", it: "Addormentato" }, stasis: { en: "Stasis", it: "Stasi" }, clones: { en: "Magic Clones", it: "Cloni Magici" }, invisible: { en: "Invisible", it: "Invisibile" },
  barrier: { en: "Barrier", it: "Barriera" }, commanded: { en: "Commanded", it: "Comandato" }, dazzled: { en: "Dazzled", it: "Abbagliato" }, marked: { en: "Marked by Light", it: "Marchiato dalla Luce" },
  magicarmor: { en: "Magic Armor", it: "Armatura Magica" } };
const STATUS_NAME = Object.fromEntries([...STATUSES, { id: "prone", en: "Prone", it: "Prono" }].map(s => [s.id, s]));
/**
 * What the automation module will do with an action: a list of { kind, text } chips in the UI language.
 * kind: card | status | save | armor | self | anim | none
 */
export function automationPreview({ name = "", text = "", hit = 0, dmg = "0", color = "normal" }, lang = "en", animClass = null) {
  const L = (en, it) => (lang === "it" ? it : en);
  const chips = [];
  const hasDmg = dmg && String(dmg).trim() !== "0";
  if (num(hit) > 0) chips.push({ kind: "card", text: L(`D12 to hit: ${num(hit)} or lower`, `D12 per colpire: ${num(hit)} o meno`) });
  const save = parseSave(text);
  if (hasDmg) chips.push({ kind: "card", text: save ? L(`${showDice(dmg)} damage if the roll fails`, `${showDice(dmg)} danni se il tiro fallisce`) : L(`${showDice(dmg)} damage, Dodge / Parry buttons`, `${showDice(dmg)} danni, pulsanti Schiva / Para`) });
  if (color === "red") chips.push({ kind: "card", text: L("Can’t be parried", "Non si para") });
  if (color === "blue") chips.push({ kind: "card", text: L("Can’t be dodged", "Non si schiva") });
  if (hasDmg && ignoresArmor(text)) chips.push({ kind: "armor", text: L("Ignores Armor", "Ignora l’Armatura") });
  if (save) {
    const ab = byId(ABILITIES, save.abil);
    chips.push({ kind: "save", text: `${L("Roll", "Tiro di")} ${L(ab?.en ?? save.label, ab?.it ?? save.label)}${save.opposed ? L(" (opposed)", " (contrapposto)") : ""}${save.dis ? L(" with Disadvantage", " con Svantaggio") : ""}` });
  }
  const fx = monsterActionEffects(name, text);
  const targetFx = new Set(fx.filter(f => f.who === "target").map(f => f.id));
  for (const s of parseStatuses(text)) {
    const n = STATUS_NAME[s.id]; if (!n) continue;
    chips.push({ kind: "status", text: `${L(n.en, n.it)}${s.duration ? ` · ${showDice(s.duration)} Round` : ""}` });
  }
  for (const f of fx) {
    const lab = SELF_LABEL[f.id]; if (!lab) continue;
    const txt = L(lab.en, lab.it).replace("{a}", f.armor ?? "");
    chips.push({ kind: f.who === "self" ? "self" : "status", text: f.who === "self" ? `${txt} ${L("on the Monster", "sul Mostro")}` : txt });
  }
  void targetFx;
  if (!chips.some(c => c.kind !== "card") && !hasDmg) chips.push({ kind: "none", text: L("Text only: the GM resolves it.", "Solo testo: lo risolve il GM.") });
  if (animClass) chips.push({ kind: "anim", text: `${L("Animation", "Animazione")}: ${animClass}` });
  return chips;
}

/* ------------------------------------------------------------------ stat guidance per Threat */
/** Fallback ranges read from the rulebook's Monster cards (Threat 1–3). The live window recomputes them from the compendium. */
export const RULEBOOK_RANGES = {
  1: { n: 11, hearts: [7, 11, 16], armor: [0, 1, 2], stamina: [0, 0, 1] },
  2: { n: 17, hearts: [15, 23, 35], armor: [0, 2, 3], stamina: [0, 1, 2] },
  3: { n: 13, hearts: [30, 40, 70], armor: [0, 2, 3], stamina: [1, 3, 5] },
};
/** min / median / max of each stat for each Threat, from a list of { threat, hearts, armor, stamina }. */
export function statRanges(monsters) {
  const by = {};
  for (const m of monsters) {
    const t = num(m.threat); if (!(t > 0) || m.threatX) continue;
    (by[t] ??= []).push(m);
  }
  const mm = arr => { const s = [...arr].sort((a, b) => a - b); return [s[0], s[Math.floor((s.length - 1) / 2)], s.at(-1)]; };
  return Object.fromEntries(Object.entries(by).map(([t, list]) => [t, { n: list.length, hearts: mm(list.map(m => num(m.hearts))), armor: mm(list.map(m => num(m.armor))), stamina: mm(list.map(m => num(m.stamina))) }]));
}
export function compareToRange(value, range) {
  if (!range) return "typical";
  if (num(value) > range[2]) return "high";
  if (num(value) < range[0]) return "low";
  return "typical";
}
